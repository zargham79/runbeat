package com.runbeat.app.fitness

import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Calendar
import java.util.Locale

enum class Status { IDLE, RUNNING, PAUSED }

data class RunUi(
    val status: Status = Status.IDLE,
    val type: String = "Run",
    val elapsedSec: Long = 0,
    val distanceM: Double = 0.0,
    val paceSecPerKm: Int = 0,
    val calories: Int = 0,
    val gpsFix: Boolean = false
)

/** Live tracking state shared between RunService and the UI. */
object RunBus {
    val state = MutableStateFlow(RunUi())
    /** Live route (lat, lng) of the current activity, for the on-screen map. */
    val route = MutableStateFlow<List<Pair<Double, Double>>>(emptyList())
}

fun fmtTime(sec: Long): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}
fun fmtPace(secPerKm: Int): String =
    if (secPerKm <= 0 || secPerKm > 3600) "--:--" else String.format(Locale.US, "%d:%02d", secPerKm / 60, secPerKm % 60)
fun fmtKm(meters: Double): String = String.format(Locale.US, "%.2f", meters / 1000)

fun startOfDay(offsetDays: Int = 0): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    c.add(Calendar.DAY_OF_YEAR, offsetDays)
    return c.timeInMillis
}
fun startOfWeek(): Long {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    c.set(Calendar.DAY_OF_WEEK, c.firstDayOfWeek)
    return c.timeInMillis
}
