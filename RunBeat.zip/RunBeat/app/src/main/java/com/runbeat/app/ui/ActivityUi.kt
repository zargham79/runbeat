package com.runbeat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.runbeat.app.data.RunEntity
import com.runbeat.app.fitness.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private fun typeIcon(t: String) = when (t) {
    "Walk" -> Icons.Default.DirectionsWalk; "Cycle" -> Icons.Default.DirectionsBike; else -> Icons.Default.DirectionsRun
}
private fun dateOf(ms: Long) = SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(ms))

@Composable
fun ActivityScreen(vm: Vm, onPlan: () -> Unit) {
    val runs by vm.runs.collectAsState()
    var open by remember { mutableStateOf<RunEntity?>(null) }
    var page by remember { mutableIntStateOf(0) }
    val cur = open
    if (cur != null) { RunDetail(vm, cur) { open = null }; return }
    Column(Modifier.fillMaxSize()) {
        Text("Activity", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 12.dp))
        ChipRow {
            listOf("Overview", "History", "Plans", "Badges", "Map", "Profile").forEachIndexed { i, p -> PillChip(p, page == i) { page = i } }
        }
        when (page) {
            0 -> OverviewPage(vm, runs)
            1 -> HistoryPage(runs) { open = it }
            2 -> PlansPage(vm, onPlan)
            3 -> BadgesPage(runs)
            4 -> MapScreen(vm)
            else -> ProfilePage(vm, runs)
        }
    }
}

@Composable
fun Mini(label: String, value: String, modifier: Modifier) {
    Column(modifier) { Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(label, fontSize = 12.sp, color = Dim) }
}

// ============================================================ overview
@Composable
fun OverviewPage(vm: Vm, runs: List<RunEntity>) {
    var period by remember { mutableStateOf("Week") }
    val sel = runs.filter { it.startTime >= periodStart(period) }
    val km = sel.sumOf { it.distanceM } / 1000
    val secs = sel.sumOf { it.durationSec }
    val bars = remember(runs, period) { buckets(period, runs) }
    val maxBar = max(1.0, bars.maxOfOrNull { it.second } ?: 0.0)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Week", "Month", "Year", "All").forEach { p -> PillChip(p, period == p) { period = p } }
            }
        }
        item {
            Column {
                Text(String.format(Locale.US, "%.1f", km), fontSize = 76.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
                Text("KILOMETERS · ${period.uppercase()}", color = Dim, fontSize = 12.sp)
            }
        }
        if (period == "Week") item {
            Column {
                LinearProgressIndicator(progress = { (km / vm.goalKm).coerceIn(0.0, 1.0).toFloat() },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Volt, trackColor = Surface2)
                Text(String.format(Locale.US, "Weekly goal: %.1f / %.0f km", km, vm.goalKm), color = Dim, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        item {
            Row(Modifier.fillMaxWidth()) {
                Mini("Activities", sel.size.toString(), Modifier.weight(1f))
                Mini("Time", fmtTime(secs), Modifier.weight(1f))
                Mini("Avg pace /km", fmtPace(if (km > 0) (secs / km).toInt() else 0), Modifier.weight(1f))
                Mini("Kcal", sel.sumOf { it.calories }.toString(), Modifier.weight(1f))
            }
        }
        if (bars.isNotEmpty()) item {
            Row(Modifier.fillMaxWidth().height(130.dp), verticalAlignment = Alignment.Bottom) {
                bars.forEach { (label, v) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                        if (v > 0) Text(String.format(Locale.US, "%.1f", v), fontSize = 10.sp, color = Dim)
                        Box(Modifier.width(18.dp).height(max(4.0, v / maxBar * 80).dp).clip(RoundedCornerShape(4.dp))
                            .background(if (v > 0) Volt else Surface2))
                        Text(label, fontSize = 12.sp, color = Dim)
                    }
                }
            }
        }
        item { RecordsCard(runs) }
    }
}

@Composable
fun RecordsCard(runs: List<RunEntity>) {
    val longest = runs.maxByOrNull { it.distanceM }
    val longestTime = runs.maxByOrNull { it.durationSec }
    val bestKm = runs.flatMap { r -> r.splits.split(';').mapNotNull { it.toIntOrNull() } }.minOrNull()
    val best5k = runs.filter { it.distanceM >= 5000 }.minByOrNull { avgPaceOf(it) }
    val topCal = runs.maxByOrNull { it.calories }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Personal records", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        RecordRow("Longest distance", longest?.let { "${fmtKm(it.distanceM)} km" })
        RecordRow("Longest time", longestTime?.let { fmtTime(it.durationSec) })
        RecordRow("Fastest kilometer", bestKm?.let { "${fmtPace(it)} /km" })
        RecordRow("Best 5K+ pace", best5k?.let { "${fmtPace(avgPaceOf(it))} /km" })
        RecordRow("Most calories", topCal?.let { "${it.calories} kcal" })
    }
}

@Composable
private fun RecordRow(label: String, value: String?) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, Modifier.weight(1f), color = Dim)
        Text(value ?: "—", fontWeight = FontWeight.SemiBold, color = if (value != null) Volt else Dim)
    }
}

// ============================================================ history
@Composable
fun HistoryPage(runs: List<RunEntity>, onOpen: (RunEntity) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (runs.isEmpty()) item { Text("No activities yet – tap GO on the Run tab.", color = Dim) }
        items(runs) { r ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surface1)
                .clickable { onOpen(r) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(typeIcon(r.type), r.type, tint = Volt)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${fmtKm(r.distanceM)} km · ${fmtTime(r.durationSec)}", fontWeight = FontWeight.Bold)
                    Text(dateOf(r.startTime), fontSize = 12.sp, color = Dim)
                }
                Text("${fmtPace(avgPaceOf(r))} /km", color = Color.LightGray)
            }
        }
    }
}

// ============================================================ plans
@Composable
fun PlansPage(vm: Vm, onStart: () -> Unit) {
    var sel by remember { mutableIntStateOf(0) }
    val plan = Plans.all[sel]
    val done = plan.sessions.count { it.id in vm.doneSessions }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Plans.all.forEachIndexed { i, p -> PillChip(p.name, sel == i) { sel = i } }
            }
        }
        item {
            Column(Modifier.padding(vertical = 8.dp)) {
                Text(plan.blurb, color = Dim, fontSize = 13.sp)
                LinearProgressIndicator(progress = { done.toFloat() / plan.sessions.size },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(8.dp).clip(RoundedCornerShape(4.dp)), color = Volt, trackColor = Surface2)
                Text("$done of ${plan.sessions.size} sessions done", color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
        plan.sessions.groupBy { it.week }.forEach { (week, sessions) ->
            item { Text("Week $week", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 10.dp)) }
            items(sessions) { s ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surface1).padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(s.id in vm.doneSessions, { vm.toggleSession(s.id) })
                    Column(Modifier.weight(1f)) {
                        Text(s.title, fontWeight = FontWeight.Medium)
                        val goal = if (s.kind == "Distance") String.format(Locale.US, "%.1f km", s.value) else "${s.value.toInt()} min"
                        Text("$goal · ${s.note}", color = Dim, fontSize = 12.sp)
                    }
                    TextButton({ vm.planGoal = s.kind to s.value; onStart() }) { Text("Start", color = Volt) }
                }
            }
        }
    }
}

// ============================================================ badges
@Composable
fun BadgesPage(runs: List<RunEntity>) {
    val badges = remember(runs) { computeBadges(runs) }
    LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(badges) { b ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(64.dp).clip(RoundedCornerShape(32.dp)).background(if (b.unlocked) Volt else Surface2),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.EmojiEvents, null, tint = if (b.unlocked) Color.Black else Dim, modifier = Modifier.size(34.dp))
                }
                Text(b.title, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                Text(b.desc, color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                Text(b.progress, color = if (b.unlocked) Volt else Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}

// ============================================================ profile: settings + gear
@Composable
fun ProfilePage(vm: Vm, runs: List<RunEntity>) {
    var weightText by remember { mutableStateOf(vm.weightKg.toInt().toString()) }
    var goalText by remember { mutableStateOf(vm.goalKm.toInt().toString()) }
    var shoeText by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Settings", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(weightText, { weightText = it; it.toFloatOrNull()?.let { v -> if (v in 20f..300f) vm.updateWeight(v) } },
                        label = { Text("Weight (kg)") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(goalText, { goalText = it; it.toFloatOrNull()?.let { v -> if (v in 1f..1000f) vm.updateGoal(v) } },
                        label = { Text("Weekly goal (km)") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Voice coach")
                        Text("Speaks every km; music ducks while it talks", fontSize = 12.sp, color = Dim)
                    }
                    Switch(vm.voiceCoach, { vm.updateVoice(it) })
                }
            }
        }
        item { Text("Gear", fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        items(vm.shoes) { s ->
            val km = runs.filter { it.shoe == s }.sumOf { it.distanceM } / 1000
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surface1).padding(end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(vm.currentShoe == s, { vm.pickShoe(s) })
                Column(Modifier.weight(1f)) {
                    Text(s, fontWeight = FontWeight.Medium)
                    Text(String.format(Locale.US, "%.1f km", km), color = Dim, fontSize = 12.sp)
                }
                IconButton({ vm.removeShoe(s) }) { Icon(Icons.Default.Delete, "Remove", tint = Dim) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(shoeText, { shoeText = it }, label = { Text("Add shoes") }, singleLine = true, modifier = Modifier.weight(1f))
                Button({ vm.addShoe(shoeText); shoeText = "" }) { Text("Add") }
            }
        }
    }
}

// ============================================================ single activity
@Composable
fun RunDetail(vm: Vm, r: RunEntity, onBack: () -> Unit) {
    val pts = remember(r.id) { parseRoute(r.route) }
    val splits = remember(r.id) { r.splits.split(';').mapNotNull { it.toIntOrNull() } }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("${r.type} · ${dateOf(r.startTime)}", fontWeight = FontWeight.Bold)
                if (r.shoe.isNotBlank()) Text(r.shoe, color = Dim, fontSize = 12.sp)
            }
            IconButton({ vm.deleteRun(r); onBack() }) { Icon(Icons.Default.Delete, "Delete") }
        }
        Row(Modifier.fillMaxWidth()) {
            Mini("Distance km", fmtKm(r.distanceM), Modifier.weight(1f))
            Mini("Time", fmtTime(r.durationSec), Modifier.weight(1f))
            Mini("Pace /km", fmtPace(avgPaceOf(r)), Modifier.weight(1f))
            Mini("Kcal", r.calories.toString(), Modifier.weight(1f))
        }
        OsmMap(Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(12.dp)),
            routes = listOf(pts),
            markers = listOfNotNull(pts.firstOrNull()?.let { it to "Start" }, pts.lastOrNull()?.takeIf { pts.size > 1 }?.let { it to "Finish" }),
            fitPoints = pts, fitKey = r.id)
        if (splits.isNotEmpty()) {
            Text("Splits", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            val fastest = splits.min()
            LazyColumn(Modifier.weight(1f)) {
                items(splits.size) { i ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                        Text("Km ${i + 1}", Modifier.weight(1f))
                        Text("${fmtPace(splits[i])} /km", color = if (splits[i] == fastest) Volt else Color.LightGray,
                            fontWeight = if (splits[i] == fastest) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}
