package com.runbeat.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Red = Color(0xFFFF0033)
val Volt = Color(0xFFD7FF00)
val Surface1 = Color(0xFF121212)
val Surface2 = Color(0xFF212121)
val Dim = Color(0xFFAAAAAA)

@Composable
fun RbTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color.White, onPrimary = Color.Black,
            secondary = Red, background = Color.Black, onBackground = Color.White,
            surface = Surface1, onSurface = Color.White,
            surfaceVariant = Surface2, onSurfaceVariant = Dim
        ),
        content = content
    )
}
