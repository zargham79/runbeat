package com.runbeat.app.fitness

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.runbeat.app.MainActivity
import com.runbeat.app.RunBeatApp
import com.runbeat.app.data.RunEntity
import kotlinx.coroutines.*
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * Foreground service that records a GPS activity: distance, pace, calories, km splits, route.
 * Voice coach announcements use TTS with a "transient may duck" audio-focus request, so the
 * music (ExoPlayer in PlaybackService) automatically lowers while the coach speaks.
 */
class RunService : Service(), LocationListener, TextToSpeech.OnInitListener {
    companion object {
        const val START = "rb.start"; const val PAUSE = "rb.pause"
        const val RESUME = "rb.resume"; const val STOP = "rb.stop"
        const val EXTRA_TYPE = "type"; const val EXTRA_WEIGHT = "weight"; const val EXTRA_VOICE = "voice"
        private const val CH = "run_tracking"; private const val NID = 42
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var lm: LocationManager
    private lateinit var am: AudioManager

    private var st = Status.IDLE
    private var type = "Run"; private var weightKg = 70f; private var voice = true
    private var startWall = 0L; private var accumMs = 0L; private var sinceMs = 0L
    private var distance = 0.0
    private val route = ArrayList<DoubleArray>()
    private var lastLoc: Location? = null
    private var fix = false
    private val splits = ArrayList<Int>()
    private var lastSplitMs = 0L; private var nextKm = 1
    private val window = ArrayDeque<Pair<Long, Double>>()
    private var ticker: Job? = null
    private var stopRunnable: Runnable? = null

    private var tts: TextToSpeech? = null; private var ttsReady = false
    private var focusReq: AudioFocusRequest? = null
    private val pending = AtomicInteger(0); private var uid = 0

    override fun onCreate() {
        super.onCreate()
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            START -> if (st == Status.IDLE) begin(intent)
            PAUSE -> if (st == Status.RUNNING) {
                accumMs = elapsedMs(); st = Status.PAUSED; lastLoc = null
                publish(); notifyNow(); speak("Paused")
            }
            RESUME -> if (st == Status.PAUSED) {
                sinceMs = SystemClock.elapsedRealtime(); st = Status.RUNNING
                publish(); notifyNow(); speak("Resumed")
            }
            STOP -> if (st != Status.IDLE) finish() else stopSelf()
            else -> if (st == Status.IDLE) stopSelf()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------ lifecycle of a run
    private fun begin(i: Intent) {
        stopRunnable?.let { handler.removeCallbacks(it) }
        type = i.getStringExtra(EXTRA_TYPE) ?: "Run"
        weightKg = i.getFloatExtra(EXTRA_WEIGHT, 70f)
        voice = i.getBooleanExtra(EXTRA_VOICE, true)
        createChannel()
        ServiceCompat.startForeground(this, NID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)

        distance = 0.0; route.clear(); splits.clear(); window.clear()
        RunBus.route.value = emptyList()
        lastLoc = null; fix = false; nextKm = 1; lastSplitMs = 0L; accumMs = 0L
        startWall = System.currentTimeMillis(); sinceMs = SystemClock.elapsedRealtime()
        st = Status.RUNNING

        if (tts == null) tts = TextToSpeech(this, this) else speak("$type started")
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper())
        } catch (e: Exception) {
            st = Status.IDLE; RunBus.state.value = RunUi()
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return
        }
        ticker?.cancel()
        ticker = scope.launch {
            var n = 0
            while (isActive) { delay(1000); publish(); if (++n % 5 == 0) notifyNow() }
        }
        publish()
    }

    private fun finish() {
        val el = elapsedMs() / 1000; val dist = distance; val cal = calories()
        ticker?.cancel()
        try { lm.removeUpdates(this) } catch (_: Exception) {}
        st = Status.IDLE; RunBus.state.value = RunUi(); RunBus.route.value = emptyList()

        if (dist >= 50.0) {
            val entity = RunEntity(
                startTime = startWall, type = type, durationSec = el, distanceM = dist, calories = cal,
                route = route.joinToString(";") { String.format(Locale.US, "%.5f,%.5f", it[0], it[1]) },
                splits = splits.joinToString(";")
            )
            scope.launch(Dispatchers.IO) { (application as RunBeatApp).db.dao().insertRun(entity) }
        }
        speak("$type finished. ${spokenDistance(dist)} in ${spokenDuration(el)}.")
        // keep the service alive briefly so the final announcement can be spoken
        stopRunnable = Runnable { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
        handler.postDelayed(stopRunnable!!, 7000)
    }

    // ------------------------------------------------------------ GPS
    override fun onLocationChanged(loc: Location) {
        if (st != Status.RUNNING) return
        if (!loc.hasAccuracy() || loc.accuracy > 30f) return
        fix = true
        val prev = lastLoc
        if (prev == null) {
            lastLoc = loc; route.add(doubleArrayOf(loc.latitude, loc.longitude)); publishRoute(); publish(); return
        }
        val d = prev.distanceTo(loc)
        if (d < 3f) return            // ignore GPS jitter
        lastLoc = loc; distance += d
        route.add(doubleArrayOf(loc.latitude, loc.longitude))
        publishRoute()

        val el = elapsedMs()
        window.addLast(el to distance)
        while (window.size > 1 && el - window.first().first > 25_000) window.removeFirst()

        while (distance >= nextKm * 1000.0) {
            val secs = ((el - lastSplitMs) / 1000).toInt()
            splits.add(secs); lastSplitMs = el
            speak("Kilometer $nextKm. Time ${spokenDuration(el / 1000)}. " +
                "Last kilometer in ${spokenDuration(secs.toLong())}.")
            nextKm++
        }
        publish()
    }
    @Deprecated("Deprecated in Java") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    // ------------------------------------------------------------ stats
    private fun elapsedMs() = accumMs + if (st == Status.RUNNING) SystemClock.elapsedRealtime() - sinceMs else 0L

    private fun calories(): Int {
        val factor = when (type) { "Walk" -> 0.55; "Cycle" -> 0.35; else -> 1.0 }
        return (distance / 1000.0 * weightKg * factor).toInt()
    }

    private fun currentPace(): Int {
        if (window.size < 2) return 0
        val a = window.first(); val b = window.last()
        val dd = b.second - a.second; val dt = (b.first - a.first) / 1000.0
        return if (dd > 5) (dt / dd * 1000).toInt() else 0
    }

    private fun publishRoute() { RunBus.route.value = route.map { it[0] to it[1] } }

    private fun publish() {
        RunBus.state.value = RunUi(st, type, elapsedMs() / 1000, distance, currentPace(), calories(), fix)
    }

    // ------------------------------------------------------------ notification
    private fun createChannel() {
        val ch = NotificationChannel(CH, "Run tracking", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }
    private fun action(label: String, act: String, code: Int): NotificationCompat.Action {
        val pi = PendingIntent.getService(this, code, Intent(this, RunService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Action(0, label, pi)
    }
    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("$type ${if (st == Status.PAUSED) "paused" else "in progress"}")
            .setContentText("${fmtTime(elapsedMs() / 1000)} · ${fmtKm(distance)} km")
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
        if (st == Status.PAUSED) b.addAction(action("Resume", RESUME, 1)) else b.addAction(action("Pause", PAUSE, 2))
        b.addAction(action("Finish", STOP, 3))
        return b.build()
    }
    private fun notifyNow() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NID, buildNotification())
    }

    // ------------------------------------------------------------ voice coach (ducks the music)
    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts?.language = Locale.getDefault()
        tts?.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) = utteranceEnded()
            @Deprecated("Deprecated in Java") override fun onError(id: String?) = utteranceEnded()
            override fun onError(id: String?, errorCode: Int) = utteranceEnded()
        })
        ttsReady = true
        if (st == Status.RUNNING) speak("$type started")
    }

    private fun speak(text: String) {
        if (!voice || !ttsReady) return
        if (pending.getAndIncrement() == 0) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .build()
            focusReq = req; am.requestAudioFocus(req)
        }
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "u${uid++}")
    }
    private fun utteranceEnded() {
        if (pending.decrementAndGet() <= 0) {
            pending.set(0); focusReq?.let { am.abandonAudioFocusRequest(it) }; focusReq = null
        }
    }

    private fun spokenDuration(sec: Long): String {
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        return buildString {
            if (h > 0) append("$h hour${if (h > 1) "s" else ""} ")
            if (m > 0) append("$m minute${if (m > 1) "s" else ""} ")
            if (h == 0L) append("$s second${if (s != 1L) "s" else ""}")
        }.trim()
    }
    private fun spokenDistance(m: Double) = String.format(Locale.US, "%.2f kilometers", m / 1000)

    override fun onDestroy() {
        scope.cancel()
        try { lm.removeUpdates(this) } catch (_: Exception) {}
        tts?.shutdown(); tts = null
        focusReq?.let { am.abandonAudioFocusRequest(it) }
        super.onDestroy()
    }
}
