package com.runbeat.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.runbeat.app.fitness.*
import kotlinx.coroutines.delay
import org.osmdroid.util.GeoPoint
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun RunScreen(vm: Vm) {
    val c = vm.controller
    val ctx = LocalContext.current
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    val live by vm.live.collectAsState()
    val liveRoute by vm.liveRoute.collectAsState()
    var goalKind by remember { mutableStateOf("Open") }
    var goalKm by remember { mutableFloatStateOf(5f) }
    var goalMin by remember { mutableIntStateOf(30) }
    var countdown by remember { mutableIntStateOf(0) }
    var dx by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(vm.planGoal) {
        vm.planGoal?.let { (k, v) ->
            goalKind = k
            if (k == "Distance") goalKm = v else goalMin = v.toInt()
            vm.planGoal = null
        }
    }
    LaunchedEffect(countdown) {
        if (countdown > 0) {
            delay(1000)
            if (countdown == 1) {
                countdown = 0
                vm.startRun(
                    if (goalKind == "Distance") goalKm * 1000.0 else 0.0,
                    if (goalKind == "Time") goalMin * 60L else 0L
                )
            } else countdown -= 1
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) countdown = 3
        else vm.error = "Location permission is required to track activities"
    }
    fun go() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) countdown = 3
        else permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (countdown > 0) {
            Box(Modifier.fillMaxSize().background(Volt).blockTouches(), contentAlignment = Alignment.Center) {
                Text(countdown.toString(), fontSize = 180.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, color = Color.Black)
            }
        } else if (live.status == Status.IDLE) {
            // ------------------------------------------------ before the run
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Run", "Walk", "Cycle").forEach { t -> PillChip(t, vm.activityType == t) { vm.chooseActivityType(t) } }
                }
                Spacer(Modifier.height(28.dp))
                Box(Modifier.size(230.dp).clip(CircleShape).background(Volt).clickable { go() }, contentAlignment = Alignment.Center) {
                    Text("GO", fontSize = 68.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, color = Color.Black)
                }
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Open", "Distance", "Time").forEach { k -> PillChip(k, goalKind == k) { goalKind = k } }
                }
                if (goalKind == "Distance") Stepper(String.format(Locale.US, "%.1f km", goalKm), { goalKm = max(1f, goalKm - 0.5f) }, { goalKm += 0.5f })
                if (goalKind == "Time") Stepper("$goalMin min", { goalMin = max(5, goalMin - 5) }, { goalMin += 5 })
                Spacer(Modifier.height(8.dp))
                Text("Shoes · ${vm.currentShoe.ifBlank { "none selected" }}", color = Dim, fontSize = 13.sp)
                vm.error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp, textAlign = TextAlign.Center) }
                Spacer(Modifier.height(28.dp))
                RunMusicStrip(vm)
            }
        } else {
            // ------------------------------------------------ during the run
            Column(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragEnd = {
                                if (dx > 150) c?.seekToPreviousMediaItem() else if (dx < -150) c?.seekToNextMediaItem()
                                dx = 0f
                            },
                            onDragCancel = { dx = 0f }
                        ) { _, d -> dx += d }
                    }
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(if (live.status == Status.PAUSED) "PAUSED" else live.type.uppercase(), color = Volt, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(fmtKm(live.distanceM), fontSize = 104.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, maxLines = 1)
                Text("KILOMETERS", color = Dim, fontSize = 13.sp)
                if (live.goalM > 0 || live.goalSec > 0) {
                    val prog = if (live.goalM > 0) live.distanceM / live.goalM else live.elapsedSec.toDouble() / live.goalSec
                    LinearProgressIndicator(progress = { prog.coerceIn(0.0, 1.0).toFloat() },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)), color = Volt, trackColor = Surface2)
                    Text(if (prog >= 1) "Goal reached!" else "${(prog * 100).toInt()}% of goal", color = Dim, fontSize = 13.sp)
                }
                Row(Modifier.fillMaxWidth()) {
                    BigStat(fmtPace(live.paceSecPerKm), "PACE /KM", Modifier.weight(1f))
                    BigStat(fmtTime(live.elapsedSec), "TIME", Modifier.weight(1f))
                    BigStat(live.calories.toString(), "KCAL", Modifier.weight(1f))
                }
                if (!live.gpsFix) Text("Waiting for GPS signal…", color = Dim, fontSize = 13.sp)
                if (liveRoute.isNotEmpty()) {
                    val geo = remember(liveRoute) { liveRoute.map { GeoPoint(it.first, it.second) } }
                    OsmMap(Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(16.dp)),
                        routes = listOf(geo), markers = listOf(geo.last() to "You"),
                        centerOn = geo.last(), centerKey = geo.size, interactive = false)
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    if (live.status == Status.RUNNING)
                        CircleBtn(Icons.Default.Pause, "Pause", Surface2, Color.White, { vm.pauseRun() })
                    else
                        CircleBtn(Icons.Default.PlayArrow, "Resume", Volt, Color.Black, { vm.resumeRun() })
                    CircleBtn(Icons.Default.Stop, "Hold to finish", Red, Color.White, {}, { vm.stopRun() })
                }
                RunMusicStrip(vm)
            }
        }
    }
}

@Composable
fun Stepper(label: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
        IconButton(onMinus) { Icon(Icons.Default.Remove, "Less") }
        Text(label, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
        IconButton(onPlus) { Icon(Icons.Default.Add, "More") }
    }
}

@Composable
fun BigStat(value: String, label: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 32.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = Dim, fontSize = 11.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CircleBtn(icon: ImageVector, label: String, bg: Color, fg: Color, onClick: () -> Unit, onLongClick: (() -> Unit)? = null) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(88.dp).clip(CircleShape).background(bg).combinedClickable(onClick = onClick, onLongClick = onLongClick),
            contentAlignment = Alignment.Center) {
            Icon(icon, label, tint = fg, modifier = Modifier.size(44.dp))
        }
        Text(label, color = Dim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun RunMusicStrip(vm: Vm) {
    val ctx = LocalContext.current
    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var vol by remember {
        mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC))
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Surface1).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Art(vm.nowArt, 44.dp, 6.dp)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(vm.nowTitle.ifBlank { "Nothing playing" }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(vm.nowArtist.ifBlank { "Pick music in Home" }, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Dim, fontSize = 12.sp)
            }
            IconButton({ vm.controller?.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, "Previous") }
            IconButton({ vm.togglePlay() }) { Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause") }
            IconButton({ vm.controller?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Next") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.VolumeDown, null, tint = Dim, modifier = Modifier.size(20.dp))
            Slider(vol, {
                vol = it
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)).roundToInt(), 0)
            }, modifier = Modifier.weight(1f).height(28.dp))
            Icon(Icons.Default.VolumeUp, null, tint = Dim, modifier = Modifier.size(20.dp))
        }
    }
}
