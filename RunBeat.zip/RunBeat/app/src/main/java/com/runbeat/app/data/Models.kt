package com.runbeat.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** kind = "music" | "podcast". localPath != null means it's downloaded for offline use. */
@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val artUrl: String,
    val streamUrl: String,
    val downloadUrl: String,
    val kind: String,
    val localPath: String? = null
)

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(tableName = "playlist_items", primaryKeys = ["playlistId", "trackId"])
data class PlaylistItem(val playlistId: Long, val trackId: String, val position: Int)

@Entity(tableName = "podcasts")
data class PodcastEntity(
    @PrimaryKey val feedUrl: String,
    val title: String,
    val artist: String,
    val artUrl: String
)

@Entity(tableName = "runs")
data class RunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startTime: Long,
    val type: String,
    val durationSec: Long,
    val distanceM: Double,
    val calories: Int,
    val route: String,   // "lat,lng;lat,lng;..."
    val splits: String   // seconds per km, "340;352;..."
)

@Dao
interface AppDao {
    @Insert suspend fun insertRun(r: RunEntity): Long
    @Query("SELECT * FROM runs ORDER BY startTime DESC") fun runs(): Flow<List<RunEntity>>
    @Query("DELETE FROM runs WHERE id = :id") suspend fun deleteRun(id: Long)

    @Query("SELECT * FROM tracks WHERE localPath IS NOT NULL ORDER BY title")
    fun downloads(): Flow<List<TrackEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(t: TrackEntity)
    @Query("DELETE FROM tracks WHERE id = :id") suspend fun deleteTrack(id: String)
    @Query("DELETE FROM playlist_items WHERE trackId = :id") suspend fun deleteItemsForTrack(id: String)

    @Query("SELECT * FROM playlists ORDER BY name") fun playlists(): Flow<List<PlaylistEntity>>
    @Insert suspend fun addPlaylist(p: PlaylistEntity): Long
    @Query("DELETE FROM playlists WHERE id = :id") suspend fun deletePlaylist(id: Long)
    @Query("DELETE FROM playlist_items WHERE playlistId = :id") suspend fun clearItems(id: Long)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addItem(i: PlaylistItem)
    @Query("DELETE FROM playlist_items WHERE playlistId = :pid AND trackId = :tid")
    suspend fun removeItem(pid: Long, tid: String)
    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM playlist_items WHERE playlistId = :pid")
    suspend fun nextPos(pid: Long): Int
    @Query("""SELECT t.* FROM tracks t JOIN playlist_items i ON t.id = i.trackId
              WHERE i.playlistId = :pid AND t.localPath IS NOT NULL ORDER BY i.position""")
    fun playlistTracks(pid: Long): Flow<List<TrackEntity>>

    @Query("SELECT * FROM podcasts ORDER BY title") fun subs(): Flow<List<PodcastEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun subscribe(p: PodcastEntity)
    @Query("DELETE FROM podcasts WHERE feedUrl = :url") suspend fun unsubscribe(url: String)
}

@Database(
    entities = [TrackEntity::class, PlaylistEntity::class, PlaylistItem::class, PodcastEntity::class, RunEntity::class],
    version = 2, exportSchema = false
)
abstract class Db : RoomDatabase() { abstract fun dao(): AppDao }
