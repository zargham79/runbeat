package com.runbeat.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Paint
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.runbeat.app.data.Place
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File

private const val ROUTE_COLOR = 0xFFD7FF00.toInt()

fun parseRoute(s: String): List<GeoPoint> = s.split(';').mapNotNull {
    val p = it.split(',')
    val a = p.getOrNull(0)?.toDoubleOrNull(); val b = p.getOrNull(1)?.toDoubleOrNull()
    if (a != null && b != null) GeoPoint(a, b) else null
}

private fun initOsm(ctx: Context) {
    val cfg = Configuration.getInstance()
    cfg.load(ctx, ctx.getSharedPreferences("osm", Context.MODE_PRIVATE))
    cfg.userAgentValue = ctx.packageName          // required by OSM tile usage policy
    val base = File(ctx.cacheDir, "osm")
    cfg.osmdroidBasePath = base
    cfg.osmdroidTileCache = File(base, "tiles")   // app-private: no storage permission needed
}

/** Reusable OpenStreetMap view (osmdroid) with route lines, markers, centering and fit-to-bounds. */
@Composable
fun OsmMap(
    modifier: Modifier = Modifier,
    routes: List<List<GeoPoint>> = emptyList(),
    markers: List<Pair<GeoPoint, String>> = emptyList(),
    centerOn: GeoPoint? = null, centerKey: Any? = null, zoom: Double = 16.0,
    fitPoints: List<GeoPoint> = emptyList(), fitKey: Any? = null,
    interactive: Boolean = true
) {
    val ctx = LocalContext.current
    val map = remember {
        initOsm(ctx)
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(interactive)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(3.0)
            if (!interactive) setOnTouchListener { _, _ -> true }
        }
    }
    DisposableEffect(map) { map.onResume(); onDispose { map.onPause(); map.onDetach() } }

    LaunchedEffect(routes, markers) {
        map.overlays.clear()
        routes.forEach { pts ->
            map.overlays.add(Polyline().apply {
                setPoints(pts)
                outlinePaint.color = ROUTE_COLOR
                outlinePaint.strokeWidth = 10f
                outlinePaint.strokeCap = Paint.Cap.ROUND
            })
        }
        markers.forEach { (p, title) ->
            map.overlays.add(Marker(map).apply {
                position = p; this.title = title
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            })
        }
        map.invalidate()
    }
    LaunchedEffect(centerKey) {
        centerOn?.let { map.controller.setZoom(zoom); map.controller.setCenter(it) }
    }
    LaunchedEffect(fitKey) {
        if (fitPoints.size >= 2) {
            map.post { runCatching { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(fitPoints), false, 80) } }
        } else if (fitPoints.size == 1) { map.controller.setZoom(16.0); map.controller.setCenter(fitPoints[0]) }
    }

    Box(modifier) {
        AndroidView({ map }, Modifier.fillMaxSize())
        Text("© OpenStreetMap contributors", fontSize = 10.sp, color = Color.Black,
            modifier = Modifier.align(Alignment.BottomEnd).background(Color(0xAAFFFFFF)).padding(horizontal = 4.dp))
    }
}

// ------------------------------------------------------------------ helpers
@SuppressLint("MissingPermission")
fun locateMe(ctx: Context, cb: (GeoPoint?) -> Unit) {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val provider = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        .firstOrNull { try { lm.isProviderEnabled(it) } catch (e: Exception) { false } }
    if (provider == null) { cb(null); return }
    val last = try { lm.getLastKnownLocation(provider) } catch (e: SecurityException) { null }
    if (last != null) cb(GeoPoint(last.latitude, last.longitude))
    try {
        @Suppress("DEPRECATION")
        lm.requestSingleUpdate(provider, object : LocationListener {
            override fun onLocationChanged(l: Location) { cb(GeoPoint(l.latitude, l.longitude)) }
            @Deprecated("Deprecated in Java") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
        }, Looper.getMainLooper())
    } catch (e: Exception) { if (last == null) cb(null) }
}

/** Hands off to Google Maps (or any maps app) for turn-by-turn walking directions. */
fun openNavigation(ctx: Context, p: Place) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${p.lat},${p.lon}&mode=w")))
    } catch (e: ActivityNotFoundException) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("geo:${p.lat},${p.lon}?q=${p.lat},${p.lon}(${Uri.encode(p.name)})")))
        } catch (_: Exception) {}
    }
}

// ------------------------------------------------------------------ Map screen
@Composable
fun MapScreen(vm: Vm) {
    val ctx = LocalContext.current
    val runs by vm.runs.collectAsState()
    val liveRoute by vm.liveRoute.collectAsState()
    val routes = remember(runs) { runs.map { parseRoute(it.route) }.filter { it.size > 1 } }
    var showRoutes by remember { mutableStateOf(true) }
    var q by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<Place?>(null) }
    var me by remember { mutableStateOf<GeoPoint?>(null) }
    var focus by remember { mutableStateOf<GeoPoint?>(null) }
    var focusKey by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf<String?>(null) }

    fun locate() = locateMe(ctx) { p ->
        if (p == null) msg = "Couldn't get your location – is GPS turned on?"
        else { me = p; focus = p; focusKey++; msg = null }
    }
    fun hasPerm() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) locate() else msg = "Location permission is needed to show where you are"
    }
    LaunchedEffect(Unit) { if (hasPerm() && routes.isEmpty()) locate() }

    val live = remember(liveRoute) { liveRoute.map { GeoPoint(it.first, it.second) } }
    val livePos = live.lastOrNull()
    val markers = buildList {
        (livePos ?: me)?.let { add(it to "You are here") }
        picked?.let { add(GeoPoint(it.lat, it.lon) to it.name) }
    }
    val allRoutes = buildList {
        if (showRoutes) addAll(routes)
        if (live.size > 1) add(live)
    }
    val fit = if (focusKey == 0 && picked == null && routes.isNotEmpty()) routes.flatten() else emptyList()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        SearchField(q, { q = it }, "Search a place or address") { vm.searchPlaces(q) }
        StatusBar(vm)
        if (vm.places.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().clip8().background(Color(0xFF1C1C1C))) {
                vm.places.take(5).forEach { pl ->
                    Text(pl.name, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.fillMaxWidth().clickable {
                            picked = pl; focus = GeoPoint(pl.lat, pl.lon); focusKey++; vm.clearPlaces()
                        }.padding(12.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Switch(showRoutes, { showRoutes = it }); Spacer(Modifier.width(8.dp))
            Text("My routes (${routes.size})", Modifier.weight(1f))
            FilledTonalButton({ if (hasPerm()) locate() else permLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) {
                Icon(Icons.Default.MyLocation, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Me")
            }
        }
        msg?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }
        OsmMap(
            Modifier.weight(1f).fillMaxWidth().clip8(),
            routes = allRoutes, markers = markers,
            centerOn = focus, centerKey = focusKey,
            fitPoints = fit, fitKey = routes.size
        )
        picked?.let { pl ->
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(pl.name, Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                Button({ openNavigation(ctx, pl) }) {
                    Icon(Icons.Default.Navigation, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Navigate")
                }
                IconButton({ picked = null }) { Icon(Icons.Default.Close, "Clear") }
            }
        }
    }
}

private fun Modifier.clip8() = this.then(Modifier.clip(RoundedCornerShape(12.dp)))
