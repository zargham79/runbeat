package com.runbeat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.runbeat.app.data.PlaylistEntity
import com.runbeat.app.data.PodcastEntity
import com.runbeat.app.data.TrackEntity

val MOODS = listOf("Workout" to "dance", "Energize" to "rock", "Relax" to "chillout", "Focus" to "ambient",
    "Party" to "house", "Commute" to "pop", "Sleep" to "relaxation")

val GENRES = listOf(
    Triple("Electronic", "electronic", 0xFF7C4DFF), Triple("Rock", "rock", 0xFFE53935),
    Triple("Pop", "pop", 0xFFEC407A), Triple("Hip-Hop", "hiphop", 0xFFFFA000),
    Triple("Jazz", "jazz", 0xFF00897B), Triple("Classical", "classical", 0xFF5C6BC0),
    Triple("Ambient", "ambient", 0xFF26C6DA), Triple("Chillout", "chillout", 0xFF43A047),
    Triple("Dance", "dance", 0xFFFF7043), Triple("Metal", "metal", 0xFF757575),
    Triple("Folk", "folk", 0xFF8D6E63), Triple("Reggae", "reggae", 0xFF9CCC65),
    Triple("Blues", "blues", 0xFF1E88E5), Triple("Lounge", "lounge", 0xFFAB47BC),
    Triple("Indie", "indie", 0xFF26A69A), Triple("Soundtrack", "soundtrack", 0xFFD4E157)
)

// ============================================================ HOME
@Composable
fun HomeScreen(vm: Vm) {
    LaunchedEffect(Unit) { vm.loadHome() }
    val history by vm.history.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayCircleFilled, null, tint = Red, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(8.dp))
                Text("RunBeat", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton({ vm.searchOpen = true }) { Icon(Icons.Default.Search, "Search") }
            }
        }
        item {
            ChipRow { MOODS.forEach { (label, tag) -> PillChip(label) { vm.openTag(label, tag) } } }
        }
        if (history.isNotEmpty()) {
            item { SectionHeader("Listen again") }
            item { ShelfRow(vm, history) }
        }
        vm.shelves.firstOrNull()?.let { first ->
            item { SectionHeader("Quick picks") }
            item { QuickPicks(vm, first.tracks.take(12)) }
        }
        vm.shelves.forEach { s ->
            item { SectionHeader(s.title) }
            item { ShelfRow(vm, s.tracks) }
        }
        if (vm.homeLoading) item {
            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color.White)
            }
        }
        vm.homeError?.let { e ->
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(e, color = Color(0xFFFF6B6B), fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    PillChip("Retry", true) { vm.loadHome(true) }
                }
            }
        }
    }
}

// ============================================================ EXPLORE
@Composable
fun ExploreScreen(vm: Vm) {
    var page by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Explore", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ vm.searchOpen = true }) { Icon(Icons.Default.Search, "Search") }
        }
        ChipRow {
            PillChip("Moods & genres", page == 0) { page = 0 }
            PillChip("Charts", page == 1) { page = 1 }
            PillChip("Podcasts", page == 2) { page = 2 }
        }
        when (page) {
            0 -> LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(GENRES) { (label, tag, color) ->
                    Row(Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(8.dp)).background(Surface2)
                        .clickable { vm.openTag(label, tag) }) {
                        Box(Modifier.fillMaxHeight().width(6.dp).background(Color(color)))
                        Text(label, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(14.dp).align(Alignment.CenterVertically))
                    }
                }
            }
            1 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val charts = listOf(
                    "Top songs this week" to "popularity_week", "Top songs this month" to "popularity_month",
                    "All-time hits" to "popularity_total", "New releases" to "releasedate_desc",
                    "Most listened this week" to "listens_week"
                )
                items(charts) { (title, order) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Surface2)
                        .clickable { vm.openChart(title, order) }.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.TrendingUp, null, tint = Red)
                        Spacer(Modifier.width(14.dp))
                        Text(title, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    }
                }
            }
            else -> PodcastsPage(vm)
        }
    }
}

@Composable
fun PodcastsPage(vm: Vm) {
    var q by remember { mutableStateOf("") }
    val subs by vm.subs.collectAsState()
    Column(Modifier.fillMaxSize().padding(top = 4.dp)) {
        Box(Modifier.padding(horizontal = 16.dp)) { SearchField(q, { q = it }, "Search podcasts") { vm.searchPodcasts(q) } }
        ChipRow {
            listOf("running", "fitness", "news", "comedy", "health", "technology", "true crime", "business").forEach { c ->
                PillChip(c.replaceFirstChar { it.uppercase() }) { q = c; vm.searchPodcasts(c) }
            }
        }
        StatusBar(vm)
        LazyColumn(Modifier.fillMaxSize()) {
            if (vm.showResults.isEmpty() && subs.isNotEmpty()) {
                item { SectionHeader("Your subscriptions") }
                items(subs) { s -> ShowRow(vm, s) }
            }
            items(vm.showResults) { s -> ShowRow(vm, s) }
        }
    }
}

// ============================================================ SEARCH (overlay)
@Composable
fun SearchScreen(vm: Vm) {
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }
    Column(Modifier.fillMaxSize().background(Color.Black).blockTouches()) {
        Row(Modifier.fillMaxWidth().padding(end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.searchOpen = false }) { Icon(Icons.Default.ArrowBack, "Back") }
            TextField(
                q, { q = it }, singleLine = true,
                placeholder = { Text("Search songs, artists, podcasts") },
                modifier = Modifier.weight(1f).focusRequester(fr),
                shape = RoundedCornerShape(12.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Surface2, unfocusedContainerColor = Surface2,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.search(q) })
            )
        }
        ChipRow {
            PillChip("Songs", tab == 0) { tab = 0 }
            PillChip("Podcasts", tab == 1) { tab = 1 }
        }
        StatusBar(vm)
        LazyColumn(Modifier.fillMaxSize()) {
            if (tab == 0) itemsIndexed(vm.songResults) { i, t -> TrackRow(vm, t, vm.songResults, i) }
            else items(vm.showResults) { s -> ShowRow(vm, s) }
        }
    }
}

// ============================================================ LIST PAGE (genre / chart / artist)
@Composable
fun ListPageScreen(vm: Vm, page: ListPage) {
    Column(Modifier.fillMaxSize().background(Color.Black).blockTouches()) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.closeList() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text(page.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        val tracks = page.tracks
        if (tracks == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }
        } else {
            page.error?.let { Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.padding(16.dp)) }
            if (tracks.isEmpty() && page.error == null) Text("Nothing found here yet.", color = Dim, modifier = Modifier.padding(16.dp))
            if (tracks.isNotEmpty()) PlayRow(vm, tracks)
            LazyColumn(Modifier.fillMaxSize()) { itemsIndexed(tracks) { i, t -> TrackRow(vm, t, tracks, i) } }
        }
    }
}

@Composable
fun PlayRow(vm: Vm, tracks: List<TrackEntity>, extra: (@Composable RowScope.() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Button({ vm.play(tracks, 0) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) {
            Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("Play")
        }
        FilledTonalButton({ vm.shuffleAll(tracks) }, colors = ButtonDefaults.filledTonalButtonColors(containerColor = Surface2, contentColor = Color.White)) {
            Icon(Icons.Default.Shuffle, null); Spacer(Modifier.width(4.dp)); Text("Shuffle")
        }
        extra?.invoke(this)
    }
}

// ============================================================ PODCAST EPISODES (overlay)
@Composable
fun EpisodeScreen(vm: Vm, show: PodcastEntity) {
    val subs by vm.subs.collectAsState()
    val subscribed = subs.any { it.feedUrl == show.feedUrl }
    Column(Modifier.fillMaxSize().background(Color.Black).blockTouches()) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.closeShow() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Art(show.artUrl, 56.dp, 8.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(show.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(show.artist, color = Dim, fontSize = 13.sp, maxLines = 1)
            }
            PillChip(if (subscribed) "Subscribed" else "Subscribe", !subscribed) { vm.toggleSub(show, subscribed) }
        }
        StatusBar(vm)
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(vm.episodes) { i, t -> TrackRow(vm, t, vm.episodes, i) { DownloadButton(vm, t) } }
        }
    }
}

// ============================================================ LIBRARY
@Composable
fun LibraryScreen(vm: Vm) {
    val downloads by vm.downloads.collectAsState()
    val liked by vm.likedTracks.collectAsState()
    val history by vm.history.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val subs by vm.subs.collectAsState()
    var page by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<PlaylistEntity?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    val cur = open
    if (cur != null) { PlaylistDetail(vm, cur) { open = null }; return }

    val songs = downloads.filter { it.kind == "music" }
    val pods = downloads.filter { it.kind == "podcast" }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Library", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ vm.searchOpen = true }) { Icon(Icons.Default.Search, "Search") }
        }
        ChipRow {
            listOf("Playlists", "Downloads", "Liked", "History", "Podcasts").forEachIndexed { i, l -> PillChip(l, page == i) { page = i } }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            when (page) {
                0 -> {
                    item {
                        Row(Modifier.fillMaxWidth().clickable { showNew = true }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(52.dp).clip(RoundedCornerShape(6.dp)).background(Surface2), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Add, null)
                            }
                            Spacer(Modifier.width(12.dp)); Text("New playlist", fontWeight = FontWeight.Medium)
                        }
                    }
                    items(playlists) { p ->
                        Row(Modifier.fillMaxWidth().clickable { open = p }.padding(start = 16.dp, top = 6.dp, bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(52.dp).clip(RoundedCornerShape(6.dp)).background(Surface2), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.QueueMusic, null, tint = Dim)
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(p.name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            IconButton({ vm.deletePlaylist(p) }) { Icon(Icons.Default.Delete, "Delete playlist", tint = Dim) }
                        }
                    }
                }
                1 -> {
                    if (downloads.isEmpty()) item { Text("Downloaded songs and episodes appear here and play without internet.", color = Dim, modifier = Modifier.padding(16.dp)) }
                    if (songs.isNotEmpty()) { item { SectionHeader("Music (${songs.size})") }; item { PlayRow(vm, songs) } }
                    itemsIndexed(songs) { i, t -> TrackRow(vm, t, songs, i) }
                    if (pods.isNotEmpty()) item { SectionHeader("Podcast episodes (${pods.size})") }
                    itemsIndexed(pods) { i, t -> TrackRow(vm, t, pods, i) }
                }
                2 -> {
                    if (liked.isEmpty()) item { Text("Songs you like appear here. Tap ⋮ on any song and choose Like.", color = Dim, modifier = Modifier.padding(16.dp)) }
                    else item { PlayRow(vm, liked) }
                    itemsIndexed(liked) { i, t -> TrackRow(vm, t, liked, i) }
                }
                3 -> {
                    if (history.isEmpty()) item { Text("Nothing played yet.", color = Dim, modifier = Modifier.padding(16.dp)) }
                    itemsIndexed(history) { i, t -> TrackRow(vm, t, history, i) }
                }
                else -> {
                    if (subs.isEmpty()) item { Text("Subscribe to podcasts from Explore → Podcasts.", color = Dim, modifier = Modifier.padding(16.dp)) }
                    items(subs) { s -> ShowRow(vm, s) }
                }
            }
        }
    }
    if (showNew) AlertDialog(
        onDismissRequest = { showNew = false },
        title = { Text("New playlist") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("Name") }) },
        confirmButton = { TextButton({ vm.createPlaylist(name); name = ""; showNew = false }) { Text("Create") } },
        dismissButton = { TextButton({ showNew = false }) { Text("Cancel") } }
    )
}

@Composable
fun PlaylistDetail(vm: Vm, p: PlaylistEntity, onBack: () -> Unit) {
    val tracks by remember(p.id) { vm.repo.dao.playlistTracks(p.id) }.collectAsState(emptyList())
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Column {
                Text(p.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${tracks.size} songs", color = Dim, fontSize = 13.sp)
            }
        }
        if (tracks.isNotEmpty()) PlayRow(vm, tracks) {
            IconButton({ vm.downloadAll(tracks) }) { Icon(Icons.Default.Download, "Download all") }
        } else Text("Add songs with ⋮ → Add to playlist.", color = Dim, modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(tracks) { i, t ->
                TrackRow(vm, t, tracks, i) {
                    IconButton({ vm.removeFromPlaylist(p, t) }) { Icon(Icons.Default.RemoveCircleOutline, "Remove", tint = Dim) }
                }
            }
        }
    }
}
