package com.runbeat.app.ui

import android.graphics.drawable.BitmapDrawable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.palette.graphics.Palette
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.runbeat.app.fitness.fmtTime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ============================================================ mini player
@Composable
fun MiniPlayer(vm: Vm) {
    if (vm.controller == null || vm.nowTitle.isBlank()) return
    val frac = if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxWidth().background(Color(0xFF1B1B1B)).clickable { vm.nowPlayingOpen = true }) {
        Row(Modifier.padding(start = 12.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Art(vm.nowArt, 44.dp, 4.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(vm.nowTitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                Text(vm.nowArtist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Dim, fontSize = 12.sp)
            }
            IconButton({ vm.togglePlay() }) {
                Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", modifier = Modifier.size(30.dp))
            }
            IconButton({ vm.controller?.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Next") }
        }
        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().height(2.dp), color = Red, trackColor = Color(0xFF333333))
    }
}

// ============================================================ now playing (full screen)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(vm: Vm) {
    val ctx = LocalContext.current
    var base by remember { mutableStateOf(Color(0xFF3A3A3A)) }
    LaunchedEffect(vm.nowArt) {
        if (vm.nowArt.isNotBlank()) {
            val res = ctx.imageLoader.execute(ImageRequest.Builder(ctx).data(vm.nowArt).allowHardware(false).size(120).build())
            val bmp = ((res as? SuccessResult)?.drawable as? BitmapDrawable)?.bitmap
            if (bmp != null) {
                val rgb = withContext(Dispatchers.Default) {
                    val p = Palette.from(bmp).generate()
                    p.getDarkMutedColor(p.getMutedColor(0xFF3A3A3A.toInt()))
                }
                base = Color(rgb)
            }
        }
    }
    val bg by animateColorAsState(base, tween(600), label = "bg")
    var showQueue by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    val likedIds by vm.likedIds.collectAsState()
    val dlIds by vm.downloadedIds.collectAsState()
    val track = vm.currentTrack()
    val c = vm.controller

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg, Color.Black))).blockTouches()
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.nowPlayingOpen = false }) { Icon(Icons.Default.KeyboardArrowDown, "Close", modifier = Modifier.size(32.dp)) }
            Text("Now playing", Modifier.weight(1f), textAlign = TextAlign.Center, color = Dim, fontSize = 14.sp)
            if (track != null) TrackMenu(vm, track, Color.White) else Spacer(Modifier.size(48.dp))
        }
        Spacer(Modifier.height(12.dp))
        AsyncImage(
            model = vm.nowArt.ifBlank { null }, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(Surface2)
        )
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(vm.nowTitle, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(vm.nowArtist, color = Dim, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (track != null) {
                val liked = track.id in likedIds
                IconButton({ vm.toggleLike(track) }) {
                    Icon(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Like",
                        tint = if (liked) Red else Color.White, modifier = Modifier.size(28.dp))
                }
                if (track.id in dlIds) Icon(Icons.Default.DownloadDone, "Downloaded", tint = Volt, modifier = Modifier.padding(8.dp))
                else IconButton({ vm.download(track) }) { Icon(Icons.Default.Download, "Download", modifier = Modifier.size(28.dp)) }
            }
        }
        Spacer(Modifier.height(8.dp))

        var drag by remember { mutableStateOf<Float?>(null) }
        val dur = vm.durationMs.coerceAtLeast(1L)
        val frac = drag ?: (vm.positionMs.toFloat() / dur).coerceIn(0f, 1f)
        Slider(
            value = frac, onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { c?.seekTo((it * dur).toLong()) }; drag = null },
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color(0x44FFFFFF))
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmtTime((frac * dur / 1000).toLong()), color = Dim, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text(fmtTime(dur / 1000), color = Dim, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.toggleShuffle() }) { Icon(Icons.Default.Shuffle, "Shuffle", tint = if (vm.shuffle) Red else Color.White) }
            IconButton({ c?.seekToPrevious() }) { Icon(Icons.Default.SkipPrevious, "Previous", modifier = Modifier.size(40.dp)) }
            Box(Modifier.size(72.dp).clip(CircleShape).background(Color.White).clickable { vm.togglePlay() }, contentAlignment = Alignment.Center) {
                Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", tint = Color.Black, modifier = Modifier.size(44.dp))
            }
            IconButton({ c?.seekToNext() }) { Icon(Icons.Default.SkipNext, "Next", modifier = Modifier.size(40.dp)) }
            IconButton({ vm.cycleRepeat() }) {
                Icon(if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, "Repeat",
                    tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) Color.White else Red)
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            PlayerAction(Icons.Default.QueueMusic, "Queue") { showQueue = true }
            PlayerAction(Icons.Default.Bedtime, if (vm.sleepLeft > 0) "${vm.sleepLeft} min" else "Sleep timer") { showSleep = true }
            PlayerAction(Icons.Default.Speed, "${vm.speed}x") { showSpeed = true }
        }
        Spacer(Modifier.height(32.dp))
    }

    if (showQueue) ModalBottomSheet(onDismissRequest = { showQueue = false }, containerColor = Surface1) {
        val items = remember(vm.queueVersion) { vm.queue() }
        Text("Up next", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp)) {
            itemsIndexed(items) { i, m ->
                val current = m.mediaId == vm.nowId
                Row(Modifier.fillMaxWidth().clickable { vm.jumpTo(i) }.padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Art(m.mediaMetadata.artworkUri?.toString().orEmpty(), 44.dp, 4.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.mediaMetadata.title?.toString().orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (current) Red else Color.White, fontWeight = FontWeight.Medium)
                        Text(m.mediaMetadata.artist?.toString().orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis, color = Dim, fontSize = 12.sp)
                    }
                    IconButton({ vm.removeFromQueue(i) }) { Icon(Icons.Default.Close, "Remove", tint = Dim) }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
    if (showSleep) AlertDialog(
        onDismissRequest = { showSleep = false }, title = { Text("Sleep timer") },
        text = {
            Column {
                listOf(0, 5, 10, 15, 30, 45, 60).forEach { m ->
                    TextButton({ vm.startSleep(m); showSleep = false }) { Text(if (m == 0) "Off" else "$m minutes") }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton({ showSleep = false }) { Text("Close") } }
    )
    if (showSpeed) AlertDialog(
        onDismissRequest = { showSpeed = false }, title = { Text("Playback speed") },
        text = {
            Column {
                listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                    TextButton({ vm.changeSpeed(s); showSpeed = false }) { Text("${s}x") }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton({ showSpeed = false }) { Text("Close") } }
    )
}

@Composable
private fun PlayerAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label)
        Text(label, fontSize = 12.sp, color = Dim)
    }
}
