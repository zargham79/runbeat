package com.runbeat.app.ui

import android.content.Context
import android.media.AudioManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.ImeAction
import coil.compose.AsyncImage
import com.runbeat.app.data.PlaylistEntity
import com.runbeat.app.data.PodcastEntity
import com.runbeat.app.data.TrackEntity

private val Yellow = Color(0xFFFFD600)

@Composable
fun AppUi(vm: Vm) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf<Pair<String, ImageVector>>(
        "Music" to Icons.Default.Search, "Podcasts" to Icons.Default.Podcasts,
        "Library" to Icons.Default.LibraryMusic, "Run" to Icons.Default.DirectionsRun, "Activity" to Icons.Default.BarChart
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            Column {
                if (tab != 3) MiniPlayer(vm)
                NavigationBar {
                    tabs.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, label) }, label = { Text(label) })
                    }
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> DiscoverScreen(vm); 1 -> PodcastScreen(vm); 2 -> LibraryScreen(vm); 3 -> RunScreen(vm); else -> ActivityScreen(vm)
            }
        }
    }
}

// ---------------------------------------------------------------- shared pieces
@Composable
fun SearchField(value: String, onChange: (String) -> Unit, hint: String, onSearch: () -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        modifier = Modifier.fillMaxWidth(), placeholder = { Text(hint) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        trailingIcon = { IconButton(onSearch) { Icon(Icons.Default.Search, "Search") } }
    )
}

@Composable
fun TrackRow(t: TrackEntity, onClick: () -> Unit, trailing: @Composable RowScope.() -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(t.artUrl, null, Modifier.size(52.dp).clip(RoundedCornerShape(6.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(listOf(t.artist, t.album).filter { it.isNotBlank() }.joinToString(" · "),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        trailing()
    }
}

@Composable
fun DownloadButton(vm: Vm, t: TrackEntity) {
    val ids by vm.downloadedIds.collectAsState()
    val p = vm.downloading[t.id]
    when {
        t.id in ids -> Icon(Icons.Default.DownloadDone, "Downloaded", tint = Yellow, modifier = Modifier.padding(12.dp))
        p != null -> CircularProgressIndicator(progress = { p }, modifier = Modifier.padding(12.dp).size(24.dp))
        else -> IconButton({ vm.download(t) }) { Icon(Icons.Default.Download, "Download") }
    }
}

@Composable
fun StatusBar(vm: Vm) {
    if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
    vm.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(vertical = 4.dp)) }
}

@Composable
fun MiniPlayer(vm: Vm) {
    val c = vm.controller
    if (c == null || vm.nowTitle.isBlank()) return
    Surface(tonalElevation = 4.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(vm.nowTitle, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(vm.nowArtist, maxLines = 1, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
            IconButton({ if (vm.isPlaying) c.pause() else c.play() }) {
                Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause")
            }
            IconButton({ c.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Next") }
        }
    }
}

// ---------------------------------------------------------------- music
@Composable
fun DiscoverScreen(vm: Vm) {
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        SearchField(q, { q = it }, "Search tracks, artists, albums") { vm.searchMusic(q) }
        StatusBar(vm)
        LazyColumn {
            itemsIndexed(vm.music) { i, t ->
                TrackRow(t, { vm.play(vm.music, i) }) { DownloadButton(vm, t) }
            }
        }
    }
}

// ---------------------------------------------------------------- podcasts
@Composable
fun PodcastScreen(vm: Vm) {
    val show = vm.openShow
    if (show != null) { EpisodeList(vm, show); return }
    var q by remember { mutableStateOf("") }
    val subs by vm.subs.collectAsState()
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        SearchField(q, { q = it }, "Search podcasts") { vm.searchPodcasts(q) }
        StatusBar(vm)
        LazyColumn {
            if (vm.shows.isEmpty() && subs.isNotEmpty()) {
                item { Text("Subscriptions", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(vertical = 8.dp)) }
                items(subs) { s -> ShowRow(vm, s, true) }
            }
            items(vm.shows) { s -> ShowRow(vm, s, subs.any { it.feedUrl == s.feedUrl }) }
        }
    }
}

@Composable
fun ShowRow(vm: Vm, s: PodcastEntity, subscribed: Boolean) {
    Row(Modifier.fillMaxWidth().clickable { vm.openShow(s) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(s.artUrl, null, Modifier.size(56.dp).clip(RoundedCornerShape(8.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(s.artist, maxLines = 1, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
        }
        IconButton({ vm.toggleSub(s, subscribed) }) {
            Icon(if (subscribed) Icons.Default.Check else Icons.Default.Add,
                if (subscribed) "Unsubscribe" else "Subscribe", tint = if (subscribed) Yellow else Color.White)
        }
    }
}

@Composable
fun EpisodeList(vm: Vm, show: PodcastEntity) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.closeShow() }) { Icon(Icons.Default.ArrowBack, "Back") }
            Text(show.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, modifier = Modifier.weight(1f))
        }
        StatusBar(vm)
        LazyColumn {
            itemsIndexed(vm.episodes) { i, t ->
                TrackRow(t, { vm.play(vm.episodes, i) }) { DownloadButton(vm, t) }
            }
        }
    }
}

// ---------------------------------------------------------------- library
@Composable
fun LibraryScreen(vm: Vm) {
    val downloads by vm.downloads.collectAsState()
    val playlists by vm.playlists.collectAsState()
    var open by remember { mutableStateOf<PlaylistEntity?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }

    val current = open
    if (current != null) { PlaylistDetail(vm, current) { open = null }; return }

    val songs = downloads.filter { it.kind == "music" }
    val pods = downloads.filter { it.kind == "podcast" }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Playlists", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton({ showNew = true }) { Icon(Icons.Default.Add, "New playlist") }
            }
        }
        items(playlists) { p ->
            Row(Modifier.fillMaxWidth().clickable { open = p }.padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.QueueMusic, null); Spacer(Modifier.width(12.dp))
                Text(p.name, Modifier.weight(1f))
                IconButton({ vm.deletePlaylist(p) }) { Icon(Icons.Default.Delete, "Delete playlist") }
            }
        }
        item { Text("Downloaded music (${songs.size})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)) }
        itemsIndexed(songs) { i, t -> LibraryRow(vm, t, playlists) { vm.play(songs, i) } }
        item { Text("Downloaded podcasts (${pods.size})", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)) }
        itemsIndexed(pods) { i, t -> LibraryRow(vm, t, playlists) { vm.play(pods, i) } }
    }

    if (showNew) AlertDialog(
        onDismissRequest = { showNew = false },
        title = { Text("New playlist") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("Name") }) },
        confirmButton = { TextButton({ vm.createPlaylist(name); name = ""; showNew = false }) { Text("Create") } },
        dismissButton = { TextButton({ showNew = false }) { Text("Cancel") } }
    )
}

@Composable
fun LibraryRow(vm: Vm, t: TrackEntity, playlists: List<PlaylistEntity>, onPlay: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    TrackRow(t, onPlay) {
        Box {
            IconButton({ menu = true }) { Icon(Icons.Default.PlaylistAdd, "Add to playlist") }
            DropdownMenu(menu, { menu = false }) {
                if (playlists.isEmpty()) DropdownMenuItem({ Text("Create a playlist first") }, { menu = false })
                playlists.forEach { p ->
                    DropdownMenuItem({ Text(p.name) }, { vm.addToPlaylist(p, t); menu = false })
                }
            }
        }
        IconButton({ vm.deleteDownload(t) }) { Icon(Icons.Default.Delete, "Delete download") }
    }
}

@Composable
fun PlaylistDetail(vm: Vm, p: PlaylistEntity, onBack: () -> Unit) {
    val tracks by remember(p.id) { vm.repo.dao.playlistTracks(p.id) }.collectAsState(emptyList())
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text(p.name, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Button({ vm.play(tracks, 0) }, enabled = tracks.isNotEmpty()) { Text("Play all") }
        }
        LazyColumn {
            itemsIndexed(tracks) { i, t ->
                TrackRow(t, { vm.play(tracks, i) }) {
                    IconButton({ vm.removeFromPlaylist(p, t) }) { Icon(Icons.Default.RemoveCircleOutline, "Remove") }
                }
            }
        }
    }
}

@Composable
fun RowScope.BigBtn(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(Modifier.weight(1f).height(72.dp).clip(RoundedCornerShape(20.dp))
        .background(Color(0xFF2A2A2A)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = Color.White, modifier = Modifier.size(34.dp))
    }
}
