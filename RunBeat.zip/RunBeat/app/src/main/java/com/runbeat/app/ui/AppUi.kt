package com.runbeat.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.runbeat.app.fitness.Status

@Composable
fun AppUi(vm: Vm) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf<Pair<String, ImageVector>>(
        "Home" to Icons.Default.Home, "Explore" to Icons.Default.Explore, "Run" to Icons.Default.DirectionsRun,
        "Activity" to Icons.Default.BarChart, "Library" to Icons.Default.LibraryMusic
    )
    // later BackHandlers win, so the top-most overlay is declared last
    BackHandler(enabled = vm.listPage != null) { vm.closeList() }
    BackHandler(enabled = vm.openShow != null) { vm.closeShow() }
    BackHandler(enabled = vm.searchOpen) { vm.searchOpen = false }
    BackHandler(enabled = vm.nowPlayingOpen) { vm.nowPlayingOpen = false }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Scaffold(
            containerColor = Color.Black,
            bottomBar = {
                Column {
                    if (tab != 2) MiniPlayer(vm)
                    NavigationBar(containerColor = Color(0xFF0A0A0A)) {
                        tabs.forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Icon(icon, label) }, label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Color.White, selectedTextColor = Color.White,
                                    unselectedIconColor = Dim, unselectedTextColor = Dim, indicatorColor = Surface2)
                            )
                        }
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(vm)
                    1 -> ExploreScreen(vm)
                    2 -> RunScreen(vm)
                    3 -> ActivityScreen(vm) { tab = 2 }
                    else -> LibraryScreen(vm)
                }
            }
        }
        vm.listPage?.let { ListPageScreen(vm, it) }
        vm.openShow?.let { EpisodeScreen(vm, it) }
        if (vm.searchOpen) SearchScreen(vm)
        AnimatedVisibility(visible = vm.nowPlayingOpen, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            NowPlayingScreen(vm)
        }
    }
}
