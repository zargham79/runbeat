package com.runbeat.app.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.runbeat.app.data.RunEntity
import com.runbeat.app.fitness.*
import org.osmdroid.util.GeoPoint
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

private val Yellow = Color(0xFFFFD600)
private val Card = Color(0xFF1C1C1C)

// ============================================================ RUN SCREEN (tracking + music)
@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun RunScreen(vm: Vm) {
    val c = vm.controller
    val ctx = LocalContext.current
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val live by vm.live.collectAsState()
    val liveRoute by vm.liveRoute.collectAsState()
    var dx by remember { mutableFloatStateOf(0f) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true) vm.startRun()
        else vm.error = "Location permission is required to track activities"
    }
    fun start() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
            vm.startRun()
        else permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    Column(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        if (dx > 150) c?.seekToPreviousMediaItem() else if (dx < -150) c?.seekToNextMediaItem()
                        dx = 0f
                    },
                    onDragCancel = { dx = 0f }
                ) { _, d -> dx += d }
            }
            .verticalScroll(rememberScrollState()).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // ---- live stats
        Row(Modifier.fillMaxWidth()) {
            Stat("TIME", fmtTime(live.elapsedSec), Modifier.weight(1f))
            Stat("KM", fmtKm(live.distanceM), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            Stat("PACE /KM", fmtPace(live.paceSecPerKm), Modifier.weight(1f))
            Stat("KCAL", live.calories.toString(), Modifier.weight(1f))
        }
        if (live.status != Status.IDLE && !live.gpsFix)
            Text("Waiting for GPS signal…", color = Color.Gray, fontSize = 14.sp)
        vm.error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 14.sp, textAlign = TextAlign.Center) }

        // ---- start / pause / finish
        when (live.status) {
            Status.IDLE -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Run", "Walk", "Cycle").forEach { t ->
                        FilterChip(selected = vm.activityType == t, onClick = { vm.setActivityType(t) }, label = { Text(t) })
                    }
                }
                ActionBtn("START", Yellow, Color.Black, Modifier.fillMaxWidth(), onClick = { start() })
            }
            Status.RUNNING -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionBtn("PAUSE", Color(0xFF2A2A2A), Yellow, Modifier.weight(1f), onClick = { vm.pauseRun() })
                ActionBtn("HOLD TO FINISH", Color(0xFF8B1A1A), Color.White, Modifier.weight(1f), onClick = {}, onLongClick = { vm.stopRun() })
            }
            Status.PAUSED -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionBtn("RESUME", Yellow, Color.Black, Modifier.weight(1f), onClick = { vm.resumeRun() })
                ActionBtn("HOLD TO FINISH", Color(0xFF8B1A1A), Color.White, Modifier.weight(1f), onClick = {}, onLongClick = { vm.stopRun() })
            }
        }

        // ---- live map
        if (live.status != Status.IDLE && liveRoute.isNotEmpty()) {
            val geo = remember(liveRoute) { liveRoute.map { GeoPoint(it.first, it.second) } }
            OsmMap(Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(16.dp)),
                routes = listOf(geo), markers = listOf(geo.last() to "You"),
                centerOn = geo.last(), centerKey = geo.size, interactive = false)
        }

        // ---- music
        Text(vm.nowTitle.ifBlank { "Pick music in Music, Podcasts or Library" },
            color = Yellow, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            BigBtn(Icons.Default.SkipPrevious, "Previous") { c?.seekToPreviousMediaItem() }
            Box(Modifier.size(110.dp).clip(CircleShape).background(Yellow)
                .clickable { if (vm.isPlaying) c?.pause() else c?.play() }, contentAlignment = Alignment.Center) {
                Icon(if (vm.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause",
                    tint = Color.Black, modifier = Modifier.size(70.dp))
            }
            BigBtn(Icons.Default.SkipNext, "Next") { c?.seekToNextMediaItem() }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigBtn(Icons.Default.VolumeDown, "Volume down") {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            }
            BigBtn(Icons.Default.Replay10, "Back 10s") { c?.seekBack() }
            BigBtn(Icons.Default.Forward30, "Forward 30s") { c?.seekForward() }
            BigBtn(Icons.Default.VolumeUp, "Volume up") {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            }
        }
        Text("Swipe left / right anywhere to change track", color = Color.Gray, fontSize = 13.sp)
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = Color.Gray, fontSize = 13.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ActionBtn(text: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit, onLongClick: (() -> Unit)? = null) {
    Box(modifier.height(80.dp).clip(RoundedCornerShape(20.dp)).background(bg)
        .combinedClickable(onClick = onClick, onLongClick = onLongClick), contentAlignment = Alignment.Center) {
        Text(text, color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

// ============================================================ ACTIVITY (stats + history + settings)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivityScreen(vm: Vm) {
    var open by remember { mutableStateOf<RunEntity?>(null) }
    var page by remember { mutableIntStateOf(0) }
    val cur = open
    if (cur != null) { RunDetail(vm, cur) { open = null }; return }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 12.dp, top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(page == 0, { page = 0 }, label = { Text("Overview") })
            FilterChip(page == 1, { page = 1 }, label = { Text("Map") })
        }
        if (page == 0) ActivityOverview(vm) { open = it } else MapScreen(vm)
    }
}

@Composable
fun ActivityOverview(vm: Vm, onOpen: (RunEntity) -> Unit) {
    val runs by vm.runs.collectAsState()
    val weekStart = remember(runs) { startOfWeek() }
    val week = runs.filter { it.startTime >= weekStart }
    val weekKm = week.sumOf { it.distanceM } / 1000
    val days = remember(runs) {
        (-6..0).map { off ->
            val a = startOfDay(off); val b = startOfDay(off + 1)
            val km = runs.filter { it.startTime in a until b }.sumOf { it.distanceM } / 1000
            SimpleDateFormat("E", Locale.getDefault()).format(Date(a)).take(1) to km
        }
    }
    val maxKm = max(1.0, days.maxOf { it.second })
    var weightText by remember { mutableStateOf(vm.weightKg.toInt().toString()) }
    var goalText by remember { mutableStateOf(vm.goalKm.toInt().toString()) }

    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(16.dp)) {
                Text("This week", style = MaterialTheme.typography.titleMedium)
                Text(String.format(Locale.US, "%.1f / %.0f km", weekKm, vm.goalKm), fontSize = 28.sp,
                    fontWeight = FontWeight.Bold, color = Yellow)
                LinearProgressIndicator(progress = { (weekKm / vm.goalKm).coerceIn(0.0, 1.0).toFloat() },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Row(Modifier.fillMaxWidth()) {
                    Mini("Activities", week.size.toString(), Modifier.weight(1f))
                    Mini("Time", fmtTime(week.sumOf { it.durationSec }), Modifier.weight(1f))
                    Mini("Kcal", week.sumOf { it.calories }.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().height(120.dp), verticalAlignment = Alignment.Bottom) {
                    days.forEach { (label, km) ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            if (km > 0) Text(String.format(Locale.US, "%.1f", km), fontSize = 10.sp, color = Color.Gray)
                            Box(Modifier.width(18.dp).height(max(4.0, km / maxKm * 70).dp)
                                .clip(RoundedCornerShape(4.dp)).background(if (km > 0) Yellow else Color(0xFF333333)))
                            Text(label, fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Settings", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(weightText, { weightText = it; it.toFloatOrNull()?.let { v -> if (v in 20f..300f) vm.updateWeight(v) } },
                        label = { Text("Weight (kg)") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(goalText, { goalText = it; it.toFloatOrNull()?.let { v -> if (v in 1f..1000f) vm.updateGoal(v) } },
                        label = { Text("Weekly goal (km)") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Voice coach")
                        Text("Speaks every km; music ducks while it talks", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(vm.voiceCoach, { vm.updateVoice(it) })
                }
            }
        }
        item { Text("History", style = MaterialTheme.typography.titleMedium) }
        if (runs.isEmpty()) item { Text("No activities yet – start one from the Run tab.", color = Color.Gray) }
        items(runs) { r ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Card)
                .clickable { onOpen(r) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(typeIcon(r.type), r.type, tint = Yellow)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${fmtKm(r.distanceM)} km · ${fmtTime(r.durationSec)}", fontWeight = FontWeight.Bold)
                    Text(SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(r.startTime)),
                        fontSize = 12.sp, color = Color.Gray)
                }
                Text("${fmtPace(avgPace(r))} /km", color = Color.LightGray)
            }
        }
    }
}

private fun avgPace(r: RunEntity) = if (r.distanceM > 0) (r.durationSec / (r.distanceM / 1000)).toInt() else 0
private fun typeIcon(t: String) = when (t) {
    "Walk" -> Icons.Default.DirectionsWalk; "Cycle" -> Icons.Default.DirectionsBike; else -> Icons.Default.DirectionsRun
}

@Composable
fun Mini(label: String, value: String, modifier: Modifier) {
    Column(modifier) { Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(label, fontSize = 12.sp, color = Color.Gray) }
}

@Composable
fun RunDetail(vm: Vm, r: RunEntity, onBack: () -> Unit) {
    val pts = remember(r.id) { parseRoute(r.route) }
    val splits = remember(r.id) { r.splits.split(';').mapNotNull { it.toIntOrNull() } }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("${r.type} · ${SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(r.startTime))}",
                style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton({ vm.deleteRun(r); onBack() }) { Icon(Icons.Default.Delete, "Delete") }
        }
        Row(Modifier.fillMaxWidth()) {
            Mini("Distance km", fmtKm(r.distanceM), Modifier.weight(1f))
            Mini("Time", fmtTime(r.durationSec), Modifier.weight(1f))
            Mini("Pace /km", fmtPace(avgPace(r)), Modifier.weight(1f))
            Mini("Kcal", r.calories.toString(), Modifier.weight(1f))
        }
        OsmMap(Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(12.dp)),
            routes = listOf(pts),
            markers = listOfNotNull(pts.firstOrNull()?.let { it to "Start" }, pts.lastOrNull()?.takeIf { pts.size > 1 }?.let { it to "Finish" }),
            fitPoints = pts, fitKey = r.id)
        if (splits.isNotEmpty()) {
            Text("Splits", style = MaterialTheme.typography.titleMedium)
            val fastest = splits.min()
            LazyColumn(Modifier.weight(1f)) {
                items(splits.size) { i ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text("Km ${i + 1}", Modifier.weight(1f))
                        Text("${fmtPace(splits[i])} /km", color = if (splits[i] == fastest) Yellow else Color.LightGray,
                            fontWeight = if (splits[i] == fastest) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}

@Composable
fun RouteCanvas(pts: List<Pair<Double, Double>>) {
    Canvas(Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(12.dp)).background(Card)) {
        if (pts.size < 2) return@Canvas
        val minLat = pts.minOf { it.first }; val maxLat = pts.maxOf { it.first }
        val minLng = pts.minOf { it.second }; val maxLng = pts.maxOf { it.second }
        val k = cos(Math.toRadians((minLat + maxLat) / 2))
        val w = (maxLng - minLng) * k; val h = maxLat - minLat
        val pad = 28f
        val sc = min((size.width - 2 * pad) / max(w, 1e-9), (size.height - 2 * pad) / max(h, 1e-9))
        fun map(p: Pair<Double, Double>) = Offset(
            (pad + (p.second - minLng) * k * sc + (size.width - 2 * pad - w * sc) / 2).toFloat(),
            (size.height - pad - (p.first - minLat) * sc - (size.height - 2 * pad - h * sc) / 2).toFloat()
        )
        val path = Path()
        pts.forEachIndexed { i, p -> val o = map(p); if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y) }
        drawPath(path, Yellow, style = Stroke(width = 6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(Color(0xFF4CAF50), 11f, map(pts.first()))
        drawCircle(Color(0xFFF44336), 11f, map(pts.last()))
    }
}
