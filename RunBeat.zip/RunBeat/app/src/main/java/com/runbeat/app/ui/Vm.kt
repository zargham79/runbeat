package com.runbeat.app.ui

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.runbeat.app.RunBeatApp
import com.runbeat.app.data.*
import com.runbeat.app.fitness.RunBus
import com.runbeat.app.fitness.RunService
import com.runbeat.app.fitness.Status
import com.runbeat.app.playback.PlaybackService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

data class Shelf(val title: String, val tracks: List<TrackEntity>)
data class ListPage(val title: String, val tracks: List<TrackEntity>? = null, val error: String? = null)

class Vm(app: Application) : AndroidViewModel(app) {
    val repo = (app as RunBeatApp).repo
    private val dao = repo.dao
    private val ctx get() = getApplication<Application>()
    private val prefs = app.getSharedPreferences("runbeat", Context.MODE_PRIVATE)
    private val known = HashMap<String, TrackEntity>()

    // ------------------------------------------------------------ player state
    var controller by mutableStateOf<MediaController?>(null); private set
    var nowId by mutableStateOf(""); private set
    var nowTitle by mutableStateOf(""); private set
    var nowArtist by mutableStateOf(""); private set
    var nowArt by mutableStateOf(""); private set
    var isPlaying by mutableStateOf(false); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableIntStateOf(0); private set
    var speed by mutableFloatStateOf(1f); private set
    var queueVersion by mutableIntStateOf(0); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var sleepLeft by mutableIntStateOf(0); private set
    var nowPlayingOpen by mutableStateOf(false)

    // ------------------------------------------------------------ browse state
    var searchOpen by mutableStateOf(false)
    var shelves by mutableStateOf<List<Shelf>>(emptyList()); private set
    var homeLoading by mutableStateOf(false); private set
    var homeError by mutableStateOf<String?>(null); private set
    var listPage by mutableStateOf<ListPage?>(null); private set
    var songResults by mutableStateOf<List<TrackEntity>>(emptyList()); private set
    var showResults by mutableStateOf<List<PodcastEntity>>(emptyList()); private set
    var episodes by mutableStateOf<List<TrackEntity>>(emptyList()); private set
    var openShow by mutableStateOf<PodcastEntity?>(null); private set
    var places by mutableStateOf<List<Place>>(emptyList()); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null)
    val downloading = mutableStateMapOf<String, Float>()
    private var homeLoaded = false

    // ------------------------------------------------------------ library flows
    val downloads = dao.downloads().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val downloadedIds = downloads.map { l -> l.map { it.id }.toSet() }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val likedTracks = dao.liked().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val likedIds = likedTracks.map { l -> l.map { it.id }.toSet() }.stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val history = dao.history().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val playlists = dao.playlists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val subs = dao.subs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val runs = dao.runs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        override fun onMediaMetadataChanged(m: MediaMetadata) { syncMeta(m) }
        override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
            nowId = item?.mediaId.orEmpty()
            known[nowId]?.let { t -> viewModelScope.launch { dao.insertIgnore(t); dao.markPlayed(t.id, System.currentTimeMillis()) } }
            queueVersion++
        }
        override fun onTimelineChanged(timeline: Timeline, reason: Int) { queueVersion++ }
        override fun onShuffleModeEnabledChanged(enabled: Boolean) { shuffle = enabled }
        override fun onRepeatModeChanged(mode: Int) { repeatMode = mode }
        override fun onPlaybackParametersChanged(p: PlaybackParameters) { speed = p.speed }
    }

    private fun syncMeta(m: MediaMetadata) {
        nowTitle = m.title?.toString().orEmpty()
        nowArtist = m.artist?.toString().orEmpty()
        nowArt = m.artworkUri?.toString().orEmpty()
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            val c = f.get(); controller = c; c.addListener(listener)
            isPlaying = c.isPlaying; nowId = c.currentMediaItem?.mediaId.orEmpty()
            syncMeta(c.mediaMetadata)
            shuffle = c.shuffleModeEnabled; repeatMode = c.repeatMode; speed = c.playbackParameters.speed
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                delay(500)
                val c = controller ?: continue
                if (c.mediaItemCount == 0) continue
                positionMs = c.currentPosition
                durationMs = if (c.duration > 0) c.duration else 0L
            }
        }
    }

    override fun onCleared() { controller?.release() }

    // ------------------------------------------------------------ playback
    private fun toItem(t: TrackEntity): MediaItem {
        val local = downloads.value.firstOrNull { it.id == t.id }?.localPath ?: t.localPath
        val uri = if (local != null) Uri.fromFile(File(local)) else Uri.parse(t.streamUrl)
        return MediaItem.Builder().setMediaId(t.id).setUri(uri).setMediaMetadata(
            MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                .setArtworkUri(if (t.artUrl.isBlank()) null else Uri.parse(t.artUrl)).build()
        ).build()
    }
    private fun register(list: List<TrackEntity>) { list.forEach { known[it.id] = it } }

    fun play(list: List<TrackEntity>, index: Int) {
        val c = controller ?: return
        if (list.isEmpty()) return
        register(list)
        val i = index.coerceIn(0, list.lastIndex)
        c.setMediaItems(list.map(::toItem), i, 0L); c.prepare(); c.play()
        val t = list[i]
        viewModelScope.launch { dao.insertIgnore(t); dao.markPlayed(t.id, System.currentTimeMillis()) }
    }
    fun shuffleAll(list: List<TrackEntity>) { play(list.shuffled(), 0) }
    fun playNext(t: TrackEntity) {
        val c = controller ?: return
        register(listOf(t))
        if (c.mediaItemCount == 0) play(listOf(t), 0) else c.addMediaItem(c.currentMediaItemIndex + 1, toItem(t))
    }
    fun addToQueue(t: TrackEntity) {
        val c = controller ?: return
        register(listOf(t))
        if (c.mediaItemCount == 0) play(listOf(t), 0) else c.addMediaItem(toItem(t))
    }
    fun queue(): List<MediaItem> {
        val c = controller ?: return emptyList()
        return (0 until c.mediaItemCount).map { c.getMediaItemAt(it) }
    }
    fun jumpTo(i: Int) { controller?.seekTo(i, 0L) }
    fun removeFromQueue(i: Int) { controller?.removeMediaItem(i) }
    fun togglePlay() { val c = controller ?: return; if (c.isPlaying) c.pause() else c.play() }
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun changeSpeed(s: Float) { controller?.setPlaybackSpeed(s) }
    fun currentTrack(): TrackEntity? = known[nowId]

    private var sleepJob: Job? = null
    fun startSleep(min: Int) {
        sleepJob?.cancel(); sleepLeft = min
        if (min <= 0) return
        sleepJob = viewModelScope.launch {
            var left = min
            while (left > 0) { sleepLeft = left; delay(60_000); left-- }
            sleepLeft = 0; controller?.pause()
        }
    }

    // ------------------------------------------------------------ discovery
    private fun launchTask(block: suspend () -> Unit) = viewModelScope.launch {
        loading = true; error = null
        try { block() } catch (e: Exception) { error = e.message ?: "Something went wrong" }
        loading = false
    }

    fun loadHome(force: Boolean = false) {
        if (homeLoaded && !force) return
        homeLoaded = true
        viewModelScope.launch {
            homeLoading = true; homeError = null
            val defs = listOf<Pair<String, suspend () -> List<TrackEntity>>>(
                "Trending this week" to { repo.tracks(order = "popularity_week", limit = 24) },
                "New releases" to { repo.tracks(order = "releasedate_desc", limit = 20) },
                "Workout mix" to { repo.tracks(tag = "dance", order = "popularity_month", limit = 20) },
                "Chill out" to { repo.tracks(tag = "chillout", order = "popularity_month", limit = 20) },
                "Rock favourites" to { repo.tracks(tag = "rock", order = "popularity_total", limit = 20) }
            )
            val out = ArrayList<Shelf>()
            for ((title, load) in defs) {
                try {
                    val l = load()
                    if (l.isNotEmpty()) { out += Shelf(title, l); shelves = out.toList() }
                } catch (e: Exception) { homeError = e.message; homeLoaded = false; break }
            }
            homeLoading = false
        }
    }

    fun openList(title: String, load: suspend () -> List<TrackEntity>) {
        listPage = ListPage(title)
        viewModelScope.launch {
            val result = try { ListPage(title, load()) } catch (e: Exception) { ListPage(title, emptyList(), e.message) }
            if (listPage?.title == title) listPage = result
        }
    }
    fun closeList() { listPage = null }
    fun openArtist(name: String) = openList(name) { repo.tracks(artist = name, limit = 40) }
    fun openTag(title: String, tag: String) = openList(title) { repo.tracks(tag = tag, order = "popularity_month", limit = 40) }
    fun openChart(title: String, order: String) = openList(title) { repo.tracks(order = order, limit = 50) }

    fun search(q: String) {
        if (q.isBlank()) return
        viewModelScope.launch {
            loading = true; error = null
            try { songResults = repo.tracks(search = q.trim(), limit = 40) } catch (e: Exception) { error = e.message }
            try { showResults = repo.searchPodcasts(q.trim()) } catch (e: Exception) { if (error == null) error = e.message }
            loading = false
        }
    }
    fun searchPodcasts(q: String) { if (q.isNotBlank()) launchTask { showResults = repo.searchPodcasts(q.trim()) } }
    fun openShow(s: PodcastEntity) { openShow = s; episodes = emptyList(); launchTask { episodes = repo.episodes(s) } }
    fun closeShow() { openShow = null }
    fun toggleSub(s: PodcastEntity, subscribed: Boolean) = viewModelScope.launch {
        if (subscribed) dao.unsubscribe(s.feedUrl) else dao.subscribe(s)
    }
    fun searchPlaces(q: String) {
        if (q.isNotBlank()) launchTask { places = repo.searchPlaces(q.trim()); if (places.isEmpty()) error = "No places found" }
    }
    fun clearPlaces() { places = emptyList() }

    // ------------------------------------------------------------ likes, downloads, playlists
    fun toggleLike(t: TrackEntity) = viewModelScope.launch {
        if (t.id in likedIds.value) dao.setLiked(t.id, false) else { dao.insertIgnore(t); dao.setLiked(t.id, true) }
    }
    fun download(t: TrackEntity) {
        if (downloading.containsKey(t.id)) return
        downloading[t.id] = 0f
        viewModelScope.launch {
            try { repo.download(t) { downloading[t.id] = it } }
            catch (e: Exception) { error = "Download failed: ${e.message}" }
            finally { downloading.remove(t.id) }
        }
    }
    fun downloadAll(list: List<TrackEntity>) { list.filter { it.id !in downloadedIds.value }.forEach { download(it) } }
    fun deleteDownload(t: TrackEntity) = viewModelScope.launch { repo.deleteDownload(t.id) }

    fun createPlaylist(name: String) = viewModelScope.launch {
        if (name.isNotBlank()) dao.addPlaylist(PlaylistEntity(name = name.trim()))
    }
    fun createPlaylistAndAdd(name: String, t: TrackEntity) = viewModelScope.launch {
        if (name.isBlank()) return@launch
        val id = dao.addPlaylist(PlaylistEntity(name = name.trim()))
        dao.insertIgnore(t); dao.addItem(PlaylistItem(id, t.id, 0))
    }
    fun deletePlaylist(p: PlaylistEntity) = viewModelScope.launch { dao.clearItems(p.id); dao.deletePlaylist(p.id) }
    fun addToPlaylist(p: PlaylistEntity, t: TrackEntity) = viewModelScope.launch {
        dao.insertIgnore(t); dao.addItem(PlaylistItem(p.id, t.id, dao.nextPos(p.id)))
    }
    fun removeFromPlaylist(p: PlaylistEntity, t: TrackEntity) = viewModelScope.launch { dao.removeItem(p.id, t.id) }

    // ------------------------------------------------------------ fitness
    var weightKg by mutableStateOf(prefs.getFloat("weight", 70f)); private set
    var goalKm by mutableStateOf(prefs.getFloat("goal", 20f)); private set
    var voiceCoach by mutableStateOf(prefs.getBoolean("voice", true)); private set
    var activityType by mutableStateOf(prefs.getString("type", "Run") ?: "Run"); private set
    var shoes by mutableStateOf((prefs.getString("shoes", "") ?: "").split("|").filter { it.isNotBlank() }); private set
    var currentShoe by mutableStateOf(prefs.getString("shoe", "") ?: ""); private set
    var doneSessions by mutableStateOf<Set<String>>(prefs.getStringSet("done", emptySet())?.toSet() ?: emptySet()); private set
    var planGoal by mutableStateOf<Pair<String, Float>?>(null)

    fun updateWeight(v: Float) { weightKg = v; prefs.edit().putFloat("weight", v).apply() }
    fun updateGoal(v: Float) { goalKm = v; prefs.edit().putFloat("goal", v).apply() }
    fun updateVoice(v: Boolean) { voiceCoach = v; prefs.edit().putBoolean("voice", v).apply() }
    fun chooseActivityType(t: String) { activityType = t; prefs.edit().putString("type", t).apply() }
    fun addShoe(n: String) {
        val name = n.trim()
        if (name.isBlank() || name in shoes) return
        shoes = shoes + name; prefs.edit().putString("shoes", shoes.joinToString("|")).apply()
        if (currentShoe.isBlank()) pickShoe(name)
    }
    fun pickShoe(n: String) { currentShoe = n; prefs.edit().putString("shoe", n).apply() }
    fun removeShoe(n: String) {
        shoes = shoes - n; prefs.edit().putString("shoes", shoes.joinToString("|")).apply()
        if (currentShoe == n) pickShoe("")
    }
    fun toggleSession(id: String) {
        doneSessions = if (id in doneSessions) doneSessions - id else doneSessions + id
        prefs.edit().putStringSet("done", doneSessions.toMutableSet()).apply()
    }

    val live = RunBus.state
    val liveRoute = RunBus.route

    fun startRun(goalM: Double, goalSec: Long) {
        error = null
        val i = Intent(ctx, RunService::class.java).setAction(RunService.START)
            .putExtra(RunService.EXTRA_TYPE, activityType)
            .putExtra(RunService.EXTRA_WEIGHT, weightKg)
            .putExtra(RunService.EXTRA_VOICE, voiceCoach)
            .putExtra(RunService.EXTRA_GOAL_M, goalM)
            .putExtra(RunService.EXTRA_GOAL_SEC, goalSec)
            .putExtra(RunService.EXTRA_SHOE, currentShoe)
        ContextCompat.startForegroundService(ctx, i)
    }
    private fun sendRun(action: String) {
        if (live.value.status == Status.IDLE) return
        ctx.startService(Intent(ctx, RunService::class.java).setAction(action))
    }
    fun pauseRun() = sendRun(RunService.PAUSE)
    fun resumeRun() = sendRun(RunService.RESUME)
    fun stopRun() = sendRun(RunService.STOP)
    fun deleteRun(r: RunEntity) = viewModelScope.launch { dao.deleteRun(r.id) }
}
