package com.runbeat.app.ui

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.runbeat.app.fitness.RunBus
import com.runbeat.app.fitness.RunService
import com.runbeat.app.fitness.Status
import android.net.Uri
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.runbeat.app.RunBeatApp
import com.runbeat.app.data.*
import com.runbeat.app.playback.PlaybackService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class Vm(app: Application) : AndroidViewModel(app) {
    val repo = (app as RunBeatApp).repo
    private val dao = repo.dao

    var controller by mutableStateOf<MediaController?>(null); private set
    var nowTitle by mutableStateOf(""); private set
    var nowArtist by mutableStateOf(""); private set
    var isPlaying by mutableStateOf(false); private set

    var music by mutableStateOf<List<TrackEntity>>(emptyList()); private set
    var shows by mutableStateOf<List<PodcastEntity>>(emptyList()); private set
    var episodes by mutableStateOf<List<TrackEntity>>(emptyList()); private set
    var openShow by mutableStateOf<PodcastEntity?>(null); private set
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null)
    val downloading = mutableStateMapOf<String, Float>()

    val downloads = dao.downloads().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val downloadedIds = downloads.map { l -> l.map { it.id }.toSet() }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())
    val playlists = dao.playlists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val subs = dao.subs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        override fun onMediaMetadataChanged(m: MediaMetadata) {
            nowTitle = m.title?.toString().orEmpty(); nowArtist = m.artist?.toString().orEmpty()
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            val c = f.get(); controller = c; c.addListener(listener)
            isPlaying = c.isPlaying
            nowTitle = c.mediaMetadata.title?.toString().orEmpty()
            nowArtist = c.mediaMetadata.artist?.toString().orEmpty()
        }, ContextCompat.getMainExecutor(app))
    }

    override fun onCleared() { controller?.release() }

    // ---------- fitness ----------
    private val ctx get() = getApplication<Application>()
    private val prefs = app.getSharedPreferences("runbeat", Context.MODE_PRIVATE)
    var weightKg by mutableStateOf(prefs.getFloat("weight", 70f)); private set
    var goalKm by mutableStateOf(prefs.getFloat("goal", 20f)); private set
    var voiceCoach by mutableStateOf(prefs.getBoolean("voice", true)); private set
    var activityType by mutableStateOf(prefs.getString("type", "Run") ?: "Run"); private set
    fun updateWeight(v: Float) { weightKg = v; prefs.edit().putFloat("weight", v).apply() }
    fun updateGoal(v: Float) { goalKm = v; prefs.edit().putFloat("goal", v).apply() }
    fun updateVoice(v: Boolean) { voiceCoach = v; prefs.edit().putBoolean("voice", v).apply() }
    fun setActivityType(t: String) { activityType = t; prefs.edit().putString("type", t).apply() }

    val live = RunBus.state
    val liveRoute = RunBus.route
    var places by mutableStateOf<List<Place>>(emptyList()); private set
    fun searchPlaces(q: String) { if (q.isNotBlank()) run { places = repo.searchPlaces(q.trim()); if (places.isEmpty()) error = "No places found" } }
    fun clearPlaces() { places = emptyList() }
    val runs = dao.runs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun startRun() {
        error = null
        val i = Intent(ctx, RunService::class.java).setAction(RunService.START)
            .putExtra(RunService.EXTRA_TYPE, activityType)
            .putExtra(RunService.EXTRA_WEIGHT, weightKg)
            .putExtra(RunService.EXTRA_VOICE, voiceCoach)
        ContextCompat.startForegroundService(ctx, i)
    }
    private fun sendRun(action: String) {
        if (live.value.status == Status.IDLE) return
        ctx.startService(Intent(ctx, RunService::class.java).setAction(action))
    }
    fun pauseRun() = sendRun(RunService.PAUSE)
    fun resumeRun() = sendRun(RunService.RESUME)
    fun stopRun() = sendRun(RunService.STOP)
    fun deleteRun(r: RunEntity) = viewModelScope.launch { dao.deleteRun(r.id) }

    // ---------- playback ----------
    private fun toItem(t: TrackEntity): MediaItem {
        // Prefer the offline copy whenever one exists.
        val local = downloads.value.firstOrNull { it.id == t.id }?.localPath ?: t.localPath
        val uri = if (local != null) Uri.fromFile(File(local)) else Uri.parse(t.streamUrl)
        return MediaItem.Builder().setMediaId(t.id).setUri(uri).setMediaMetadata(
            MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                .setArtworkUri(if (t.artUrl.isBlank()) null else Uri.parse(t.artUrl)).build()
        ).build()
    }

    fun play(list: List<TrackEntity>, index: Int) {
        val c = controller ?: return
        c.setMediaItems(list.map(::toItem), index, 0L); c.prepare(); c.play()
    }

    // ---------- discovery ----------
    private fun run(block: suspend () -> Unit) = viewModelScope.launch {
        loading = true; error = null
        try { block() } catch (e: Exception) { error = e.message ?: "Something went wrong" }
        loading = false
    }

    fun searchMusic(q: String) { if (q.isNotBlank()) run { music = repo.searchMusic(q.trim()) } }
    fun searchPodcasts(q: String) { if (q.isNotBlank()) run { shows = repo.searchPodcasts(q.trim()) } }
    fun openShow(s: PodcastEntity) { openShow = s; episodes = emptyList(); run { episodes = repo.episodes(s) } }
    fun closeShow() { openShow = null }
    fun toggleSub(s: PodcastEntity, subscribed: Boolean) = viewModelScope.launch {
        if (subscribed) dao.unsubscribe(s.feedUrl) else dao.subscribe(s)
    }

    // ---------- offline ----------
    fun download(t: TrackEntity) {
        if (downloading.containsKey(t.id)) return
        downloading[t.id] = 0f
        viewModelScope.launch {
            try { repo.download(t) { downloading[t.id] = it } }
            catch (e: Exception) { error = "Download failed: ${e.message}" }
            finally { downloading.remove(t.id) }
        }
    }
    fun deleteDownload(t: TrackEntity) = viewModelScope.launch { repo.deleteDownload(t) }

    // ---------- playlists (offline content only) ----------
    fun createPlaylist(name: String) = viewModelScope.launch {
        if (name.isNotBlank()) dao.addPlaylist(PlaylistEntity(name = name.trim()))
    }
    fun deletePlaylist(p: PlaylistEntity) = viewModelScope.launch { dao.clearItems(p.id); dao.deletePlaylist(p.id) }
    fun addToPlaylist(p: PlaylistEntity, t: TrackEntity) = viewModelScope.launch {
        dao.addItem(PlaylistItem(p.id, t.id, dao.nextPos(p.id)))
    }
    fun removeFromPlaylist(p: PlaylistEntity, t: TrackEntity) = viewModelScope.launch { dao.removeItem(p.id, t.id) }
}
