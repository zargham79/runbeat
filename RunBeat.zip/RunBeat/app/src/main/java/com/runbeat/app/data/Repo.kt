package com.runbeat.app.data

import android.content.Context
import android.util.Xml
import com.runbeat.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.File
import java.net.URLEncoder

data class Place(val name: String, val lat: Double, val lon: Double)

class Repo(private val ctx: Context, val dao: AppDao) {
    private val http = OkHttpClient()
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun get(url: String): ByteArray =
        http.newCall(Request.Builder().url(url).build()).execute().use {
            check(it.isSuccessful) { "HTTP ${it.code}" }
            it.body!!.bytes()
        }

    /** Music via Jamendo (Creative Commons / artist-licensed, downloads permitted). */
    suspend fun tracks(
        search: String? = null, tag: String? = null, artist: String? = null,
        order: String? = null, limit: Int = 30
    ): List<TrackEntity> = withContext(Dispatchers.IO) {
        check(BuildConfig.JAMENDO_CLIENT_ID.isNotBlank()) {
            "Missing Jamendo client id – add the JAMENDO_CLIENT_ID secret and rebuild"
        }
        val sb = StringBuilder("https://api.jamendo.com/v3.0/tracks/?client_id=${BuildConfig.JAMENDO_CLIENT_ID}" +
            "&format=json&limit=$limit&audiodownload_allowed=true&audiodlformat=mp32&imagesize=300")
        search?.let { sb.append("&search=").append(enc(it)) }
        tag?.let { sb.append("&tags=").append(enc(it)) }
        artist?.let { sb.append("&artist_name=").append(enc(it)) }
        order?.let { sb.append("&order=").append(enc(it)) }
        val root = JSONObject(String(get(sb.toString())))
        val h = root.optJSONObject("headers")
        if (h != null && h.optString("status") == "failed")
            throw IllegalStateException(h.optString("error_message", "Jamendo error"))
        val arr = root.getJSONArray("results")
        (0 until arr.length()).map { arr.getJSONObject(it) }.map { o ->
            TrackEntity(
                id = "jam:" + o.getString("id"),
                title = o.optString("name"), artist = o.optString("artist_name"),
                album = o.optString("album_name"), artUrl = o.optString("image"),
                streamUrl = o.optString("audio"), downloadUrl = o.optString("audiodownload"),
                kind = "music"
            )
        }.filter { it.streamUrl.isNotBlank() && it.downloadUrl.isNotBlank() }
    }

    /** Place / address search via OpenStreetMap Nominatim (needs an identifying User-Agent). */
    suspend fun searchPlaces(q: String): List<Place> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("https://nominatim.openstreetmap.org/search?format=json&limit=6&q=${enc(q)}")
            .header("User-Agent", "RunBeat/1.0 (Android)").build()
        val body = http.newCall(req).execute().use { check(it.isSuccessful) { "HTTP ${it.code}" }; it.body!!.string() }
        val arr = JSONArray(body)
        (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            Place(it.optString("display_name"), it.getString("lat").toDouble(), it.getString("lon").toDouble())
        }
    }

    /** Podcast directory via Apple's public iTunes Search API (returns RSS feed URLs). */
    suspend fun searchPodcasts(q: String): List<PodcastEntity> = withContext(Dispatchers.IO) {
        val arr = JSONObject(String(get("https://itunes.apple.com/search?media=podcast&limit=25&term=${enc(q)}")))
            .getJSONArray("results")
        (0 until arr.length()).map { arr.getJSONObject(it) }.map { o ->
            PodcastEntity(o.optString("feedUrl"), o.optString("collectionName"),
                o.optString("artistName"), o.optString("artworkUrl600"))
        }.filter { it.feedUrl.isNotBlank() }
    }

    /** Parses an RSS feed into playable episodes. */
    suspend fun episodes(show: PodcastEntity): List<TrackEntity> = withContext(Dispatchers.IO) {
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(get(show.feedUrl)), null)
        val out = mutableListOf<TrackEntity>()
        var inItem = false; var title = ""; var enc = ""
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when {
                    p.name == "item" -> { inItem = true; title = ""; enc = "" }
                    inItem && p.name == "title" -> title = p.nextText()
                    inItem && p.name == "enclosure" -> enc = p.getAttributeValue(null, "url") ?: ""
                }
            } else if (ev == XmlPullParser.END_TAG && p.name == "item") {
                inItem = false
                if (enc.isNotBlank()) out += TrackEntity(
                    id = "pod:" + enc.hashCode(), title = title.trim(), artist = show.title,
                    album = "", artUrl = show.artUrl, streamUrl = enc, downloadUrl = enc, kind = "podcast"
                )
            }
            ev = p.next()
        }
        out.take(100)
    }

    /** Saves the file to app storage and marks the track as downloaded. */
    suspend fun download(t: TrackEntity, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val dir = File(ctx.getExternalFilesDir(null), "downloads").apply { mkdirs() }
        val ext = if (t.kind == "music") "mp3"
        else t.downloadUrl.substringBefore('?').substringAfterLast('.', "mp3").take(4)
        val f = File(dir, "${t.id.replace(':', '_')}.$ext")
        http.newCall(Request.Builder().url(t.downloadUrl).build()).execute().use { r ->
            check(r.isSuccessful) { "HTTP ${r.code}" }
            val body = r.body!!
            val total = body.contentLength()
            var done = 0L; var last = 0f
            body.byteStream().use { input ->
                f.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf); if (n < 0) break
                        out.write(buf, 0, n); done += n
                        if (total > 0) {
                            val p = done.toFloat() / total
                            if (p - last > 0.01f) { last = p; onProgress(p) }
                        }
                    }
                }
            }
        }
        dao.insertIgnore(t)
        dao.setLocal(t.id, f.absolutePath)
    }

    suspend fun deleteDownload(id: String) = withContext(Dispatchers.IO) {
        dao.track(id)?.localPath?.let { File(it).delete() }
        dao.setLocal(id, null)
    }
}
