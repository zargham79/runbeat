package com.runbeat.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.runbeat.app.data.PodcastEntity
import com.runbeat.app.data.TrackEntity

fun Modifier.blockTouches(): Modifier = this.pointerInput(Unit) { detectTapGestures { } }

@Composable
fun Art(url: String, size: Dp, radius: Dp = 6.dp) {
    AsyncImage(
        model = url.ifBlank { null }, contentDescription = null, contentScale = ContentScale.Crop,
        modifier = Modifier.size(size).clip(RoundedCornerShape(radius)).background(Surface2)
    )
}

@Composable
fun SectionHeader(title: String) {
    Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 10.dp))
}

@Composable
fun PillChip(label: String, selected: Boolean = false, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(if (selected) Color.White else Surface2)
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(label, color = if (selected) Color.Black else Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ChipRow(content: @Composable RowScope.() -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit, hint: String, onSearch: () -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        modifier = Modifier.fillMaxWidth(), placeholder = { Text(hint) },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        trailingIcon = { IconButton(onSearch) { Icon(Icons.Default.Search, "Search") } }
    )
}

@Composable
fun StatusBar(vm: Vm) {
    if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Red, trackColor = Surface2)
    vm.error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
}

@Composable
fun DownloadButton(vm: Vm, t: TrackEntity) {
    val ids by vm.downloadedIds.collectAsState()
    val p = vm.downloading[t.id]
    when {
        t.id in ids -> Icon(Icons.Default.DownloadDone, "Downloaded", tint = Volt, modifier = Modifier.padding(12.dp))
        p != null -> CircularProgressIndicator(progress = { p }, modifier = Modifier.padding(12.dp).size(24.dp), color = Color.White)
        else -> IconButton({ vm.download(t) }) { Icon(Icons.Default.Download, "Download", tint = Dim) }
    }
}

@Composable
fun TrackMenu(vm: Vm, t: TrackEntity, tint: Color = Dim) {
    var open by remember { mutableStateOf(false) }
    var sub by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    val likedIds by vm.likedIds.collectAsState()
    val dlIds by vm.downloadedIds.collectAsState()
    val playlists by vm.playlists.collectAsState()
    Box {
        IconButton({ sub = 0; open = true }) { Icon(Icons.Default.MoreVert, "More", tint = tint) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            if (sub == 0) {
                DropdownMenuItem(text = { Text("Play next") }, onClick = { vm.playNext(t); open = false })
                DropdownMenuItem(text = { Text("Add to queue") }, onClick = { vm.addToQueue(t); open = false })
                DropdownMenuItem(text = { Text(if (t.id in likedIds) "Remove from liked" else "Like") },
                    onClick = { vm.toggleLike(t); open = false })
                if (t.id in dlIds) DropdownMenuItem(text = { Text("Remove download") }, onClick = { vm.deleteDownload(t); open = false })
                else DropdownMenuItem(text = { Text("Download") }, onClick = { vm.download(t); open = false })
                DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { sub = 1 })
                if (t.kind == "music" && t.artist.isNotBlank())
                    DropdownMenuItem(text = { Text("Go to artist") }, onClick = { vm.openArtist(t.artist); open = false })
            } else {
                DropdownMenuItem(text = { Text("‹  Back") }, onClick = { sub = 0 })
                playlists.forEach { p ->
                    DropdownMenuItem(text = { Text(p.name) }, onClick = { vm.addToPlaylist(p, t); open = false })
                }
                DropdownMenuItem(text = { Text("+  New playlist") }, onClick = { open = false; dlg = true })
            }
        }
    }
    if (dlg) AlertDialog(
        onDismissRequest = { dlg = false },
        title = { Text("New playlist") },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("Name") }) },
        confirmButton = { TextButton({ vm.createPlaylistAndAdd(name, t); name = ""; dlg = false }) { Text("Create") } },
        dismissButton = { TextButton({ dlg = false }) { Text("Cancel") } }
    )
}

@Composable
fun TrackRow(vm: Vm, t: TrackEntity, list: List<TrackEntity>, index: Int, extra: (@Composable RowScope.() -> Unit)? = null) {
    val dlIds by vm.downloadedIds.collectAsState()
    val current = vm.nowId == t.id
    Row(Modifier.fillMaxWidth().clickable { vm.play(list, index) }.padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Art(t.artUrl, 52.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
                color = if (current) Red else Color.White)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (t.id in dlIds) Icon(Icons.Default.DownloadDone, null, tint = Dim, modifier = Modifier.size(14.dp))
                Text(listOf(t.artist, t.album).filter { it.isNotBlank() }.joinToString(" · "),
                    maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = Dim)
            }
        }
        extra?.invoke(this)
        TrackMenu(vm, t)
    }
}

@Composable
fun ShelfRow(vm: Vm, tracks: List<TrackEntity>) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        itemsIndexed(tracks) { i, t ->
            Column(Modifier.width(150.dp).clickable { vm.play(tracks, i) }) {
                Art(t.artUrl, 150.dp, 8.dp)
                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
                    fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
                Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Dim, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun QuickPicks(vm: Vm, tracks: List<TrackEntity>) {
    LazyRow(contentPadding = PaddingValues(horizontal = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        itemsIndexed(tracks.chunked(4)) { page, chunk ->
            Column(Modifier.width(310.dp)) {
                chunk.forEachIndexed { j, t -> TrackRow(vm, t, tracks, page * 4 + j) }
            }
        }
    }
}

@Composable
fun ShowRow(vm: Vm, s: PodcastEntity) {
    val subs by vm.subs.collectAsState()
    val subscribed = subs.any { it.feedUrl == s.feedUrl }
    Row(Modifier.fillMaxWidth().clickable { vm.openShow(s) }.padding(start = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Art(s.artUrl, 56.dp, 8.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(s.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = Dim)
        }
        IconButton({ vm.toggleSub(s, subscribed) }) {
            Icon(if (subscribed) Icons.Default.Check else Icons.Default.Add,
                if (subscribed) "Unsubscribe" else "Subscribe", tint = if (subscribed) Red else Color.White)
        }
    }
}
