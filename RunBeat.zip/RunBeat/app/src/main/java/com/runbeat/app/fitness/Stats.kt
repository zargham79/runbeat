package com.runbeat.app.fitness

import com.runbeat.app.data.RunEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max
import kotlin.math.min

private fun zeroed(): Calendar {
    val c = Calendar.getInstance()
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c
}
fun startOfMonth(): Long { val c = zeroed(); c.set(Calendar.DAY_OF_MONTH, 1); return c.timeInMillis }
fun startOfYear(): Long { val c = zeroed(); c.set(Calendar.DAY_OF_YEAR, 1); return c.timeInMillis }
fun periodStart(period: String): Long = when (period) {
    "Week" -> startOfWeek(); "Month" -> startOfMonth(); "Year" -> startOfYear(); else -> 0L
}

fun avgPaceOf(r: RunEntity): Int = if (r.distanceM > 0) (r.durationSec / (r.distanceM / 1000)).toInt() else 0

private fun kmBetween(runs: List<RunEntity>, a: Long, b: Long): Double =
    runs.filter { it.startTime in a until b }.sumOf { it.distanceM } / 1000

/** Bars for the overview chart: label -> km. */
fun buckets(period: String, runs: List<RunEntity>): List<Pair<String, Double>> = when (period) {
    "Week" -> (-6..0).map { off ->
        val a = startOfDay(off); val b = startOfDay(off + 1)
        SimpleDateFormat("E", Locale.getDefault()).format(Date(a)).take(1) to kmBetween(runs, a, b)
    }
    "Month" -> (3 downTo 0).map { i ->
        val a = startOfDay(-(i * 7 + 6)); val b = startOfDay(-(i * 7) + 1)
        "W${4 - i}" to kmBetween(runs, a, b)
    }
    "Year" -> (11 downTo 0).map { m ->
        val c = zeroed(); c.set(Calendar.DAY_OF_MONTH, 1); c.add(Calendar.MONTH, -m)
        val a = c.timeInMillis
        val label = SimpleDateFormat("MMM", Locale.getDefault()).format(c.time).take(1)
        c.add(Calendar.MONTH, 1)
        label to kmBetween(runs, a, c.timeInMillis)
    }
    else -> emptyList()
}

// ------------------------------------------------------------------ badges
data class Badge(val title: String, val desc: String, val unlocked: Boolean, val progress: String)

fun computeBadges(runs: List<RunEntity>): List<Badge> {
    val totalKm = runs.sumOf { it.distanceM } / 1000
    val maxKm = (runs.maxOfOrNull { it.distanceM } ?: 0.0) / 1000
    val days = runs.map { (it.startTime + TimeZone.getDefault().getOffset(it.startTime)) / 86_400_000L }.distinct().sorted()
    var best = 0; var cur = 0; var prev = Long.MIN_VALUE
    for (d in days) { cur = if (d == prev + 1) cur + 1 else 1; best = max(best, cur); prev = d }
    fun hour(t: Long): Int = Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.HOUR_OF_DAY)
    val early = runs.any { hour(it.startTime) < 7 }
    val night = runs.any { hour(it.startTime) >= 21 }
    val fast = runs.any { it.distanceM >= 3000 && avgPaceOf(it) in 1..299 }
    fun p(v: Double, goal: Double) = String.format(Locale.US, "%.1f / %.1f km", min(v, goal), goal)
    return listOf(
        Badge("First steps", "Complete your first activity", runs.isNotEmpty(), "${min(runs.size, 1)} / 1"),
        Badge("5K club", "Cover 5 km in one go", maxKm >= 5, p(maxKm, 5.0)),
        Badge("10K club", "Cover 10 km in one go", maxKm >= 10, p(maxKm, 10.0)),
        Badge("Half marathoner", "Cover 21.1 km in one go", maxKm >= 21.1, p(maxKm, 21.1)),
        Badge("50 km total", "Reach 50 km overall", totalKm >= 50, p(totalKm, 50.0)),
        Badge("100 km total", "Reach 100 km overall", totalKm >= 100, p(totalKm, 100.0)),
        Badge("250 km total", "Reach 250 km overall", totalKm >= 250, p(totalKm, 250.0)),
        Badge("On a roll", "Be active 7 days in a row", best >= 7, "${min(best, 7)} / 7 days"),
        Badge("Early bird", "Start an activity before 7 am", early, if (early) "Done" else "Not yet"),
        Badge("Night owl", "Start an activity after 9 pm", night, if (night) "Done" else "Not yet"),
        Badge("Speedster", "Average under 5:00 /km over 3 km+", fast, if (fast) "Done" else "Not yet")
    )
}

// ------------------------------------------------------------------ training plans
data class PlanSession(val id: String, val week: Int, val title: String, val kind: String, val value: Float, val note: String)
data class Plan(val id: String, val name: String, val blurb: String, val sessions: List<PlanSession>)

object Plans {
    private fun build(id: String, easy: List<Double>, mins: List<Int>, long: List<Double>, goalName: String): List<PlanSession> {
        val out = ArrayList<PlanSession>()
        for (w in 0 until 8) {
            out += PlanSession("${id}_w${w}_0", w + 1, "Easy run", "Distance", easy[w].toFloat(), "Conversational pace")
            out += PlanSession("${id}_w${w}_1", w + 1, "Tempo effort", "Time", mins[w].toFloat(), "Comfortably hard, steady pace")
            out += PlanSession("${id}_w${w}_2", w + 1, if (w == 7) goalName else "Long run", "Distance", long[w].toFloat(),
                if (w == 7) "Race day effort – you're ready" else "Slow and steady")
        }
        return out
    }
    val all = listOf(
        Plan("5k", "Beginner 5K", "8 weeks · 3 sessions a week",
            build("5k", listOf(2.0, 2.0, 2.5, 3.0, 3.0, 3.5, 4.0, 3.0), listOf(20, 22, 24, 25, 28, 30, 30, 25),
                listOf(2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.0), "5K goal run")),
        Plan("10k", "10K builder", "8 weeks · 3 sessions a week",
            build("10k", listOf(4.0, 4.0, 5.0, 5.0, 6.0, 6.0, 5.0, 5.0), listOf(30, 32, 35, 38, 40, 42, 40, 30),
                listOf(5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 10.0, 10.0), "10K goal run"))
    )
}
