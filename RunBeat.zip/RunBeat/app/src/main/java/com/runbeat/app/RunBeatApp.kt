package com.runbeat.app

import android.app.Application
import androidx.room.Room
import com.runbeat.app.data.Db
import com.runbeat.app.data.Repo

class RunBeatApp : Application() {
    val db by lazy { Room.databaseBuilder(this, Db::class.java, "runbeat.db").fallbackToDestructiveMigration().build() }
    val repo by lazy { Repo(this, db.dao()) }
}
