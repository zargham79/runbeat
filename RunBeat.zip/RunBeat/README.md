# RunBeat – ad-free running music & podcast player (Android, Kotlin, Media3)

## Setup
1. Get a free client id at https://devportal.jamendo.com
2. Copy `local.properties.example` → `local.properties`, set `jamendo.client.id`
3. Open the folder in Android Studio (Koala+), let Gradle sync (it creates the wrapper), Run on a device.

## What maps to what
| Requirement | Implementation |
|---|---|
| Music search + streaming | Jamendo API (Creative Commons / artist-licensed, downloads allowed) |
| Podcast directory + RSS | iTunes Search API → RSS parsed with XmlPullParser |
| MP3 + podcast downloads | `Repo.download` → app storage + Room |
| Offline playlists | Room tables; playlists only list downloaded items |
| Bluetooth AVRCP / lock screen / notification | `PlaybackService` (Media3 `MediaSessionService`) |
| Pause on headphone disconnect | `setHandleAudioBecomingNoisy(true)` |
| Audio ducking for Strava / Google Fit | ExoPlayer audio focus handling (`handleAudioFocus = true`) |
| Run mode | `RunScreen`: giant buttons, swipe gestures, keep-screen-on, volume keys |
| Ad-free | No ad SDKs, no analytics |

## Notes
- Downloads run in the ViewModel scope; for large batches swap in WorkManager.
- Music downloads intentionally come only from sources that license them.

## Get an APK without Android Studio (GitHub Actions)
1. Create a free GitHub account, make a new repository, upload all files of this project (keep `.github/workflows/build.yml`).
2. Repo → Settings → Secrets and variables → Actions → New secret: `JAMENDO_CLIENT_ID` = your Jamendo key.
3. Actions tab → "Build APK" → Run workflow. After ~5 min open the run → Artifacts → `RunBeat-apk` → download, unzip, install `app-debug.apk`.

## Fitness features (v2)
- GPS activity tracking (Run / Walk / Cycle): live time, distance, current pace, calories, auto km splits, route
- Foreground `RunService` keeps recording with the screen off; Pause/Finish buttons in the notification
- Voice coach every km (Android TTS) – music ducks while it speaks
- Activity tab: weekly goal progress, 7-day chart, history, route map drawn from GPS, per-km splits
- Settings: body weight (calories), weekly goal, voice coach on/off
- Run tab: live stats + start/pause/hold-to-finish + big music controls
Calories are an estimate (weight × km × activity factor). Heart-rate straps and step counting are not included yet.

## Maps (v3) – OpenStreetMap via osmdroid, no API key
- Run tab: live map with your route and position while an activity is running
- Activity → Map: all your past routes, "Me" button, place/address search (Nominatim), "Navigate" hands off to Google Maps (walking)
- Activity → history item: route on a real map with Start/Finish markers
- Tiles are cached on-device; new areas need internet. Heavy commercial use of the public OSM tile servers is discouraged – swap in a commercial tile provider if you publish the app widely.

## v4 – YouTube Music-style redesign + Nike Run Club-style training
Music: Home (quick picks, listen again, trending/new/workout shelves, mood chips), Explore (genres, charts, podcasts),
search overlay, full-screen Now Playing with album-colour background, queue, shuffle/repeat, like, sleep timer,
playback speed, mini-player with progress, playlists of any songs ("Download all"), liked songs, history, artist pages.
Fitness: GO button with 3-2-1 countdown, distance/time goals with progress + voice cue, huge live stats, pause/hold-to-finish,
live map, weekly/monthly/yearly stats + charts, personal records, badges, 8-week 5K & 10K plans, shoe tracking.
